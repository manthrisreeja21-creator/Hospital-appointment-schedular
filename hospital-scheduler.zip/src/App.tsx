/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import {
  INITIAL_DOCTORS,
  INITIAL_APPOINTMENTS,
  INITIAL_PATIENT_REQUESTS,
  INITIAL_WAITING_LIST,
  TODAY_DATE,
} from './data/seedData';
import {
  Doctor,
  Appointment,
  PatientRequest,
  RescheduleIncident,
  DoctorStatus,
} from './types';
import {
  runPythonSchedule,
  bookPatientInPython,
  cancelAppointmentInPython,
  doctorUnavailableInPython,
  markNoShowInPython,
} from './api/schedulerClient';
import { Header } from './components/Header';
import { DashboardView } from './components/DashboardView';
import { ScheduleView } from './components/ScheduleView';
import { DoctorsView } from './components/DoctorsView';
import { PatientsView } from './components/PatientsView';
import { WaitingListView } from './components/WaitingListView';
import { AlgorithmDetailsView } from './components/AlgorithmDetailsView';
import { BookAppointmentModal } from './components/BookAppointmentModal';
import { WhyAppointmentModal } from './components/WhyAppointmentModal';
import { CheckCircle2, AlertCircle, Info, X } from 'lucide-react';

interface Toast {
  id: string;
  title: string;
  desc: string;
  type: 'success' | 'alert' | 'info';
}

export default function App() {
  const [activeTab, setActiveTab] = useState<string>('dashboard');
  const [doctors, setDoctors] = useState<Doctor[]>(INITIAL_DOCTORS);
  const [appointments, setAppointments] = useState<Appointment[]>(INITIAL_APPOINTMENTS);
  const [pendingRequests, setPendingRequests] = useState<PatientRequest[]>(INITIAL_PATIENT_REQUESTS);
  const [waitingList, setWaitingList] = useState<PatientRequest[]>(INITIAL_WAITING_LIST);
  const [executionData, setExecutionData] = useState<any>(null);
  const [latestIncident, setLatestIncident] = useState<RescheduleIncident | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);

  // Modals state
  const [isBookingModalOpen, setIsBookingModalOpen] = useState(false);
  const [selectedAppointmentForWhy, setSelectedAppointmentForWhy] = useState<Appointment | null>(null);
  const [toasts, setToasts] = useState<Toast[]>([]);

  // Add toast helper
  const addToast = (title: string, desc: string, type: 'success' | 'alert' | 'info' = 'info') => {
    const id = `toast-${Date.now()}-${Math.random()}`;
    setToasts((prev) => [...prev, { id, title, desc, type }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 6000);
  };

  // Initial Python backend sync on app startup
  useEffect(() => {
    async function initPythonBackend() {
      try {
        const result = await runPythonSchedule(
          INITIAL_PATIENT_REQUESTS.slice(0, 4),
          INITIAL_DOCTORS,
          INITIAL_APPOINTMENTS,
          TODAY_DATE
        );
        if (result?.execution) {
          setExecutionData(result.execution);
        }
      } catch (err) {
        console.warn('Initial Python backend call:', err);
      }
    }
    initPythonBackend();
  }, []);

  // 1. RUN AUTOMATIC SCHEDULING (Calls Python Backend POST /api/schedule)
  const handleRunAutomaticScheduling = async () => {
    if (pendingRequests.length === 0 && waitingList.length === 0) {
      addToast(
        'Queue is Clear',
        'All patient requests have already been scheduled into doctor consultation slots.',
        'info'
      );
      return;
    }

    setIsLoading(true);
    try {
      const allRequests = [...pendingRequests, ...waitingList];
      const result = await runPythonSchedule(allRequests, doctors, appointments, TODAY_DATE);

      setAppointments(result.updated_appointments || result.appointments);
      setPendingRequests([]);
      setWaitingList(result.waiting_list || []);
      setExecutionData(result.execution);

      const emergenciesCount = result.execution?.emergencies_handled || 0;
      addToast(
        'Automatic Scheduling Completed (Python Backend)',
        `Assigned ${result.appointments.length} appointments across ${result.execution?.doctors_utilized || 0} physicians. ${
          emergenciesCount > 0 ? `(${emergenciesCount} emergency cases prioritized immediately)` : ''
        }`,
        'success'
      );
    } catch (err: any) {
      console.error('Error during Python scheduling:', err);
      addToast('Scheduling Error', err.message || 'Failed to communicate with Python backend', 'alert');
    } finally {
      setIsLoading(false);
    }
  };

  // 2. REAL APPOINTMENT BOOKING (Calls Python Backend POST /api/appointments)
  const handleBookAppointment = async (
    bookingData: Omit<PatientRequest, 'id' | 'requestTimestamp' | 'status'>
  ) => {
    const newRequest: PatientRequest = {
      ...bookingData,
      id: `pat-${Date.now().toString().slice(-4)}`,
      requestTimestamp: Date.now(),
      status: 'Pending',
    };

    setIsLoading(true);
    try {
      // Send to Python backend for greedy assignment
      const response = await bookPatientInPython(newRequest, doctors, appointments, bookingData.preferredDate);

      if (response.success && response.appointment) {
        const confirmedApt = response.appointment;
        setAppointments((prev) => [confirmedApt, ...prev]);

        // Update doctor appointment count
        setDoctors((prev) =>
          prev.map((d) =>
            d.id === confirmedApt.doctorId
              ? { ...d, currentAppointmentCount: d.currentAppointmentCount + 1 }
              : d
          )
        );

        addToast(
          'Appointment Confirmed (Python Backend)',
          `${confirmedApt.patientName} scheduled with ${confirmedApt.doctorName} at ${confirmedApt.timeSlot} (${confirmedApt.date}).`,
          'success'
        );
      } else {
        // If no slot available in Python, place in Priority Triage Waiting List
        setWaitingList((prev) => [...prev, { ...newRequest, status: 'Waiting' }]);
        addToast(
          'Added to Priority Waiting Queue',
          `All consultation slots in ${newRequest.department} are currently filled. ${newRequest.patientName} placed in waiting queue according to clinical urgency (${newRequest.urgency}).`,
          'alert'
        );
      }
    } catch (err: any) {
      console.error('Error booking appointment in Python:', err);
      addToast('Booking Error', err.message || 'Python backend request failed', 'alert');
    } finally {
      setIsLoading(false);
    }
  };

  // 3. DOCTOR STATUS CHANGE (Calls Python Backend POST /api/doctor-unavailable)
  const handleUpdateDoctorStatus = async (doctorId: string, newStatus: DoctorStatus) => {
    const doc = doctors.find((d) => d.id === doctorId);
    if (!doc) return;

    if (newStatus === 'Unavailable') {
      setIsLoading(true);
      try {
        // Execute Dynamic Rescheduling Algorithm in Python
        const rescheduleResult = await doctorUnavailableInPython(
          doctorId,
          doctors,
          appointments,
          waitingList,
          TODAY_DATE
        );

        setDoctors(rescheduleResult.updated_doctors);
        setAppointments(rescheduleResult.updated_appointments);
        setWaitingList(rescheduleResult.new_waiting_requests);
        setLatestIncident(rescheduleResult.incident);
        if (rescheduleResult.execution) {
          setExecutionData(rescheduleResult.execution);
        }

        addToast(
          'Doctor Unavailable — Python Dynamic Rescheduling',
          `${doc.name} marked unavailable. ${rescheduleResult.incident.affectedAppointmentsCount} appointments affected: ${rescheduleResult.incident.successfullyRescheduledCount} rescheduled to alternative specialists, ${rescheduleResult.incident.movedToWaitingCount} moved to priority waiting queue.`,
          'alert'
        );
      } catch (err: any) {
        console.error('Error in Python doctor unavailable rescheduling:', err);
        addToast('Rescheduling Error', err.message || 'Failed to dynamic reschedule in Python', 'alert');
      } finally {
        setIsLoading(false);
      }
    } else {
      setDoctors((prev) =>
        prev.map((d) => (d.id === doctorId ? { ...d, status: newStatus } : d))
      );
      addToast('Physician Status Updated', `${doc.name} status updated to ${newStatus}.`, 'info');
    }
  };

  // 4. CANCEL APPOINTMENT (Calls Python Backend POST /api/cancel)
  const handleCancelAppointment = async (appointmentId: string) => {
    try {
      const cancelResult = await cancelAppointmentInPython(
        appointmentId,
        appointments,
        doctors,
        waitingList
      );

      setAppointments(cancelResult.updated_appointments);
      setWaitingList(cancelResult.updated_waiting_list);

      if (cancelResult.promoted_appointment) {
        addToast(
          'Slot Reallocated via Python Priority Queue',
          `Slot freed. Python Priority Queue promoted ${cancelResult.promoted_appointment.patientName} (${cancelResult.promoted_appointment.patientUrgency}) into the open slot with ${cancelResult.promoted_appointment.doctorName}!`,
          'success'
        );
      } else {
        addToast(
          'Appointment Cancelled',
          'Appointment has been cancelled and slot is now available.',
          'info'
        );
      }
    } catch (err: any) {
      console.error('Error cancelling appointment in Python:', err);
      addToast('Cancellation Error', err.message || 'Python cancel request failed', 'alert');
    }
  };

  // 5. NO-SHOW (Calls Python Backend POST /api/no-show)
  const handleMarkNoShow = async (appointmentId: string) => {
    try {
      const res = await markNoShowInPython(appointmentId, appointments, doctors, waitingList);
      setAppointments(res.updated_appointments);
      addToast('Marked as No-Show', 'Appointment marked as patient no-show.', 'info');
    } catch (err) {
      setAppointments((prev) =>
        prev.map((a) => (a.id === appointmentId ? { ...a, status: 'No Show' as const } : a))
      );
      addToast('Marked as No-Show', 'Appointment marked as patient no-show.', 'info');
    }
  };

  // 6. MARK COMPLETED
  const handleMarkCompleted = (appointmentId: string) => {
    setAppointments((prev) =>
      prev.map((a) => (a.id === appointmentId ? { ...a, status: 'Completed' as const } : a))
    );
    addToast('Consultation Completed', 'Appointment successfully completed.', 'success');
  };

  // Emergency count for header indicator
  const emergencyCount = appointments.filter(
    (a) =>
      (a.patientUrgency === 'Emergency' || a.patientUrgency === 'Critical') &&
      a.status !== 'Cancelled' &&
      a.status !== 'Completed'
  ).length + pendingRequests.filter((p) => p.urgency === 'Emergency' || p.urgency === 'Critical').length;

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 text-slate-900">
      {/* Top Clinical Header */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        emergencyCount={emergencyCount}
        pendingRequestsCount={pendingRequests.length + waitingList.length}
        onOpenBooking={() => setIsBookingModalOpen(true)}
        onRunAutomaticScheduling={handleRunAutomaticScheduling}
      />

      {/* Main View Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {activeTab === 'dashboard' && (
          <DashboardView
            appointments={appointments}
            doctors={doctors}
            pendingRequests={pendingRequests}
            waitingList={waitingList}
            latestIncident={latestIncident}
            onOpenBooking={() => setIsBookingModalOpen(true)}
            onRunAutomaticScheduling={handleRunAutomaticScheduling}
            onViewAppointmentDetails={(apt) => setSelectedAppointmentForWhy(apt)}
            onNavigateTab={(tab) => setActiveTab(tab)}
          />
        )}

        {activeTab === 'schedule' && (
          <ScheduleView
            appointments={appointments}
            doctors={doctors}
            onViewAppointmentDetails={(apt) => setSelectedAppointmentForWhy(apt)}
            onCancelAppointment={handleCancelAppointment}
            onMarkNoShow={handleMarkNoShow}
            onMarkCompleted={handleMarkCompleted}
            onOpenBooking={() => setIsBookingModalOpen(true)}
          />
        )}

        {activeTab === 'doctors' && (
          <DoctorsView
            doctors={doctors}
            appointments={appointments}
            onUpdateDoctorStatus={handleUpdateDoctorStatus}
            onViewAppointmentDetails={(apt) => setSelectedAppointmentForWhy(apt)}
          />
        )}

        {activeTab === 'patients' && (
          <PatientsView
            appointments={appointments}
            pendingRequests={pendingRequests}
            waitingList={waitingList}
            doctors={doctors}
            onOpenBooking={() => setIsBookingModalOpen(true)}
            onViewAppointmentDetails={(apt) => setSelectedAppointmentForWhy(apt)}
          />
        )}

        {activeTab === 'waiting' && (
          <WaitingListView
            waitingList={waitingList}
            pendingRequests={pendingRequests}
            onRunAutomaticScheduling={handleRunAutomaticScheduling}
            onOpenBooking={() => setIsBookingModalOpen(true)}
          />
        )}

        {activeTab === 'algorithms' && (
          <AlgorithmDetailsView
            executionData={executionData}
            appointments={appointments}
            pendingRequests={[...pendingRequests, ...waitingList]}
            doctors={doctors}
            onReRunScheduling={handleRunAutomaticScheduling}
            isBackendLoading={isLoading}
          />
        )}
      </main>

      {/* Footer */}
      <footer className="bg-white border-t border-slate-200 py-4 text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <span className="font-semibold text-slate-800">PulseCare Hospital Scheduler</span>
            <span>·</span>
            <span>Clinical Appointment & Triage System (Python DAA Engine)</span>
          </div>
          <div className="flex items-center gap-4 text-slate-500">
            <button
              onClick={() => setActiveTab('algorithms')}
              className="text-indigo-600 hover:text-indigo-800 font-medium hover:underline"
            >
              DAA Project Evaluation (Python Backend)
            </button>
            <span>·</span>
            <span>Deterministic Triage & Load Balancing</span>
          </div>
        </div>
      </footer>

      {/* Book Appointment Modal */}
      <BookAppointmentModal
        isOpen={isBookingModalOpen}
        onClose={() => setIsBookingModalOpen(false)}
        doctors={doctors}
        onSubmitBooking={handleBookAppointment}
      />

      {/* "Why this appointment was selected?" Modal */}
      <WhyAppointmentModal
        appointment={selectedAppointmentForWhy}
        onClose={() => setSelectedAppointmentForWhy(null)}
      />

      {/* Toast Notifications */}
      <div className="fixed bottom-4 right-4 z-50 flex flex-col gap-2 max-w-md w-full pointer-events-none">
        {toasts.map((t) => (
          <div
            key={t.id}
            className={`pointer-events-auto p-4 rounded-lg shadow-lg border flex items-start gap-3 transition-all transform animate-slide-up ${
              t.type === 'success'
                ? 'bg-emerald-950 text-emerald-100 border-emerald-800'
                : t.type === 'alert'
                ? 'bg-rose-950 text-rose-100 border-rose-800'
                : 'bg-slate-900 text-slate-100 border-slate-800'
            }`}
          >
            {t.type === 'success' ? (
              <CheckCircle2 className="w-5 h-5 text-emerald-400 flex-shrink-0 mt-0.5" />
            ) : t.type === 'alert' ? (
              <AlertCircle className="w-5 h-5 text-rose-400 flex-shrink-0 mt-0.5" />
            ) : (
              <Info className="w-5 h-5 text-blue-400 flex-shrink-0 mt-0.5" />
            )}
            <div className="flex-1 text-xs">
              <h4 className="font-bold text-sm leading-tight">{t.title}</h4>
              <p className="mt-0.5 opacity-90 leading-relaxed">{t.desc}</p>
            </div>
            <button
              onClick={() => setToasts((prev) => prev.filter((item) => item.id !== t.id))}
              className="text-slate-400 hover:text-white"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}
