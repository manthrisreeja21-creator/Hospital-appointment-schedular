import React, { useState } from 'react';
import {
  Stethoscope,
  Search,
  Filter,
  CheckCircle,
  Clock,
  AlertTriangle,
  UserX,
  Phone,
  Award,
  ChevronDown,
  ChevronUp,
} from 'lucide-react';
import { Doctor, Department, DoctorStatus, Appointment } from '../types';

interface DoctorsViewProps {
  doctors: Doctor[];
  appointments: Appointment[];
  onUpdateDoctorStatus: (doctorId: string, newStatus: DoctorStatus) => void;
  onViewAppointmentDetails: (apt: Appointment) => void;
}

export const DoctorsView: React.FC<DoctorsViewProps> = ({
  doctors,
  appointments,
  onUpdateDoctorStatus,
  onViewAppointmentDetails,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedDept, setSelectedDept] = useState<string>('All');
  const [expandedDoctorId, setExpandedDoctorId] = useState<string | null>(null);

  const departments: Department[] = [
    'Cardiology',
    'General Medicine',
    'Pediatrics',
    'Orthopedics',
    'Neurology',
    'Dermatology',
    'ENT',
    'Gynecology',
    'General Surgery',
    'Ophthalmology',
  ];

  const filteredDoctors = doctors.filter((doc) => {
    if (selectedDept !== 'All' && doc.department !== selectedDept) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchName = doc.name.toLowerCase().includes(q);
      const matchSpec = doc.specialization.toLowerCase().includes(q);
      const matchDept = doc.department.toLowerCase().includes(q);
      return matchName || matchSpec || matchDept;
    }
    return true;
  });

  const getDoctorAppointments = (doctorId: string) => {
    return appointments.filter(
      (a) => a.doctorId === doctorId && a.status !== 'Cancelled'
    );
  };

  const getStatusBadge = (status: DoctorStatus) => {
    switch (status) {
      case 'Available':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded text-xs font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
            Available
          </span>
        );
      case 'In Consultation':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded text-xs font-semibold bg-blue-50 text-blue-700 border border-blue-200">
            <span className="w-1.5 h-1.5 rounded-full bg-blue-500"></span>
            In Consultation
          </span>
        );
      case 'On Break':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded text-xs font-semibold bg-amber-50 text-amber-700 border border-amber-200">
            <span className="w-1.5 h-1.5 rounded-full bg-amber-500"></span>
            On Break
          </span>
        );
      case 'Fully Booked':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded text-xs font-semibold bg-purple-50 text-purple-700 border border-purple-200">
            Fully Booked
          </span>
        );
      case 'Unavailable':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded text-xs font-semibold bg-rose-50 text-rose-700 border border-rose-200">
            <UserX className="w-3 h-3 text-rose-600" />
            Unavailable
          </span>
        );
    }
  };

  return (
    <div className="space-y-5">
      {/* Top Banner & Filters */}
      <div className="bg-white border border-slate-200 rounded-lg p-4 sm:p-5 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h1 className="text-lg font-bold text-slate-900 tracking-tight flex items-center gap-2">
              <Stethoscope className="w-5 h-5 text-blue-600" />
              <span>Medical Staff Roster & Doctor Availability</span>
            </h1>
            <p className="text-xs text-slate-500 mt-1">
              Real-time physician status and appointment slots. Changing a doctor to{' '}
              <strong className="text-rose-700">"Unavailable"</strong> immediately triggers the dynamic rescheduling engine.
            </p>
          </div>

          <div className="text-xs bg-slate-50 border border-slate-200 px-3 py-2 rounded-md text-slate-600">
            <span>Active Doctors on Duty: </span>
            <strong className="text-emerald-700 font-bold tabular-nums">
              {doctors.filter((d) => d.status === 'Available' || d.status === 'In Consultation').length}
            </strong>
            <span className="text-slate-400"> / {doctors.length} Total</span>
          </div>
        </div>

        {/* Filter Controls */}
        <div className="mt-4 pt-4 border-t border-slate-100 flex flex-col sm:flex-row items-center gap-3">
          <div className="relative flex-1 w-full">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              placeholder="Search by physician name, department, or sub-specialization..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-md focus:outline-none focus:ring-1 focus:ring-blue-500 focus:bg-white"
            />
          </div>

          <div className="w-full sm:w-64">
            <select
              value={selectedDept}
              onChange={(e) => setSelectedDept(e.target.value)}
              className="w-full py-1.5 px-3 text-xs bg-slate-50 border border-slate-200 rounded-md focus:outline-none focus:ring-1 focus:ring-blue-500"
            >
              <option value="All">All Departments ({doctors.length})</option>
              {departments.map((dept) => {
                const count = doctors.filter((d) => d.department === dept).length;
                return (
                  <option key={dept} value={dept}>
                    {dept} ({count})
                  </option>
                );
              })}
            </select>
          </div>
        </div>
      </div>

      {/* Doctor Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredDoctors.map((doc) => {
          const docAppointments = getDoctorAppointments(doc.id);
          const isExpanded = expandedDoctorId === doc.id;
          const isCapacityReached = docAppointments.length >= doc.maxDailyCapacity;

          return (
            <div
              key={doc.id}
              className={`bg-white border rounded-lg shadow-xs overflow-hidden transition-all ${
                doc.status === 'Unavailable'
                  ? 'border-rose-200 bg-rose-50/20'
                  : 'border-slate-200 hover:border-slate-300'
              }`}
            >
              <div className="p-4 sm:p-5">
                {/* Header: Name, Dept, Status Badge */}
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <h3 className="text-sm font-bold text-slate-900 leading-snug">
                      {doc.name}
                    </h3>
                    <p className="text-xs text-blue-700 font-medium">{doc.specialization}</p>
                    <p className="text-[11px] text-slate-500 mt-0.5">{doc.department}</p>
                  </div>
                  <div>{getStatusBadge(doc.status)}</div>
                </div>

                {/* Qualification & Experience */}
                <div className="mt-3 pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-600">
                  <div className="flex items-center gap-1.5">
                    <Award className="w-3.5 h-3.5 text-slate-400" />
                    <span>{doc.experienceYears} Years Exp</span>
                  </div>
                  <span className="text-slate-400">·</span>
                  <span>{doc.roomNumber}</span>
                </div>

                {/* Daily Workload Progress */}
                <div className="mt-3 space-y-1">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-slate-500">Today's Workload:</span>
                    <span className="font-semibold text-slate-800 tabular-nums">
                      {docAppointments.length} / {doc.maxDailyCapacity} slots
                      {isCapacityReached && (
                        <span className="ml-1 text-purple-700 font-bold">(Capacity)</span>
                      )}
                    </span>
                  </div>
                  <div className="w-full bg-slate-100 h-1.5 rounded-full overflow-hidden">
                    <div
                      className={`h-full rounded-full ${
                        isCapacityReached
                          ? 'bg-purple-600'
                          : docAppointments.length > 0
                          ? 'bg-blue-600'
                          : 'bg-slate-300'
                      }`}
                      style={{
                        width: `${Math.min(
                          100,
                          (docAppointments.length / doc.maxDailyCapacity) * 100
                        )}%`,
                      }}
                    ></div>
                  </div>
                </div>

                {/* Status Toggle Selector - Triggers Dynamic Rescheduling if Unavailable */}
                <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between gap-2">
                  <label className="text-[11px] text-slate-500 font-medium">Status Control:</label>
                  <select
                    value={doc.status}
                    onChange={(e) => onUpdateDoctorStatus(doc.id, e.target.value as DoctorStatus)}
                    className={`py-1 px-2 text-xs rounded border focus:outline-none focus:ring-1 ${
                      doc.status === 'Unavailable'
                        ? 'bg-rose-100 text-rose-800 border-rose-300'
                        : 'bg-slate-50 text-slate-700 border-slate-200'
                    }`}
                  >
                    <option value="Available">Available</option>
                    <option value="In Consultation">In Consultation</option>
                    <option value="On Break">On Break</option>
                    <option value="Fully Booked">Fully Booked</option>
                    <option value="Unavailable">🔴 Set Unavailable (Reschedule)</option>
                  </select>
                </div>

                {/* Schedule Expand Button */}
                <div className="mt-3">
                  <button
                    onClick={() => setExpandedDoctorId(isExpanded ? null : doc.id)}
                    className="w-full py-1.5 text-xs text-slate-700 hover:text-blue-700 bg-slate-50 hover:bg-slate-100 rounded border border-slate-200 flex items-center justify-center gap-1 transition-colors"
                  >
                    <span>{isExpanded ? 'Hide Daily Slots' : "View Today's Slot Schedule"}</span>
                    {isExpanded ? (
                      <ChevronUp className="w-3.5 h-3.5" />
                    ) : (
                      <ChevronDown className="w-3.5 h-3.5" />
                    )}
                  </button>
                </div>

                {/* Expanded Slot Grid */}
                {isExpanded && (
                  <div className="mt-3 pt-3 border-t border-slate-200 space-y-2">
                    <p className="text-[11px] font-semibold text-slate-700 uppercase tracking-wider">
                      Consultation Slots:
                    </p>
                    <div className="grid grid-cols-4 gap-1.5">
                      {doc.availableSlots.map((slot) => {
                        const bookedApt = docAppointments.find((a) => a.timeSlot === slot);
                        const isBooked = !!bookedApt;
                        const isEmergency =
                          bookedApt &&
                          (bookedApt.patientUrgency === 'Emergency' ||
                            bookedApt.patientUrgency === 'Critical');

                        return (
                          <div
                            key={slot}
                            onClick={() => bookedApt && onViewAppointmentDetails(bookedApt)}
                            className={`p-1.5 rounded text-center text-[10px] font-medium transition-colors ${
                              isBooked
                                ? isEmergency
                                  ? 'bg-rose-100 text-rose-900 border border-rose-300 cursor-pointer font-bold'
                                  : 'bg-blue-100 text-blue-900 border border-blue-200 cursor-pointer'
                                : doc.status === 'Unavailable'
                                ? 'bg-slate-100 text-slate-400 border border-slate-200 opacity-60'
                                : 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                            }`}
                            title={
                              isBooked
                                ? `Booked: ${bookedApt.patientName} (${bookedApt.patientUrgency})`
                                : doc.status === 'Unavailable'
                                ? 'Doctor unavailable'
                                : 'Available for appointment booking'
                            }
                          >
                            <span className="block font-bold tabular-nums">{slot}</span>
                            <span className="block text-[9px] truncate">
                              {isBooked
                                ? isEmergency
                                  ? '🔴 Emergency'
                                  : bookedApt.patientName.split(' ')[0]
                                : 'Open'}
                            </span>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
