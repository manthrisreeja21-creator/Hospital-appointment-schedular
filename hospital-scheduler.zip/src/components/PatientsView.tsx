import React, { useState } from 'react';
import {
  Users,
  Search,
  PlusCircle,
  HelpCircle,
  Calendar,
  AlertCircle,
  Filter,
} from 'lucide-react';
import {
  PatientRequest,
  Appointment,
  Department,
  Doctor,
  UrgencyLevel,
} from '../types';

interface PatientsViewProps {
  appointments: Appointment[];
  pendingRequests: PatientRequest[];
  waitingList: PatientRequest[];
  doctors: Doctor[];
  onOpenBooking: () => void;
  onViewAppointmentDetails: (apt: Appointment) => void;
}

interface ConsolidatedPatientRow {
  id: string;
  patientName: string;
  age: number;
  contact: string;
  department: Department;
  assignedDoctorName?: string;
  urgency: UrgencyLevel;
  preferredTimeSlot?: string;
  appointmentTime?: string;
  status: string;
  appointmentRef?: Appointment;
}

export const PatientsView: React.FC<PatientsViewProps> = ({
  appointments,
  pendingRequests,
  waitingList,
  doctors,
  onOpenBooking,
  onViewAppointmentDetails,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedDept, setSelectedDept] = useState<string>('All');
  const [selectedUrgency, setSelectedUrgency] = useState<string>('All');
  const [selectedStatus, setSelectedStatus] = useState<string>('All');

  // Build unified patient records list
  const patientRows: ConsolidatedPatientRow[] = [];

  // 1. Scheduled / Active appointments
  appointments.forEach((apt) => {
    patientRows.push({
      id: apt.patientId,
      patientName: apt.patientName,
      age: apt.patientAge,
      contact: apt.patientContact,
      department: apt.department,
      assignedDoctorName: apt.doctorName,
      urgency: apt.patientUrgency,
      preferredTimeSlot: apt.timeSlot,
      appointmentTime: `${apt.date} at ${apt.timeSlot}`,
      status: apt.status,
      appointmentRef: apt,
    });
  });

  // 2. Pending Requests
  pendingRequests.forEach((req) => {
    // Avoid duplicates if already scheduled
    if (!patientRows.some((p) => p.id === req.id)) {
      patientRows.push({
        id: req.id,
        patientName: req.patientName,
        age: req.age,
        contact: req.contact,
        department: req.department,
        assignedDoctorName: 'Awaiting Scheduling',
        urgency: req.urgency,
        preferredTimeSlot: req.preferredTimeSlot || 'Earliest Feasible',
        appointmentTime: 'Not Assigned',
        status: 'Pending Scheduling',
      });
    }
  });

  // 3. Waiting List
  waitingList.forEach((req) => {
    if (!patientRows.some((p) => p.id === req.id)) {
      patientRows.push({
        id: req.id,
        patientName: req.patientName,
        age: req.age,
        contact: req.contact,
        department: req.department,
        assignedDoctorName: 'In Priority Waiting Queue',
        urgency: req.urgency,
        preferredTimeSlot: req.preferredTimeSlot || 'Earliest Feasible',
        appointmentTime: 'Waiting for Slot',
        status: 'Waiting List',
      });
    }
  });

  // Filters
  const filteredPatients = patientRows.filter((p) => {
    if (selectedDept !== 'All' && p.department !== selectedDept) return false;
    if (selectedUrgency !== 'All' && p.urgency !== selectedUrgency) return false;
    if (selectedStatus !== 'All' && p.status !== selectedStatus) return false;

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchName = p.patientName.toLowerCase().includes(q);
      const matchId = p.id.toLowerCase().includes(q);
      const matchContact = p.contact.includes(q);
      const matchDoc = p.assignedDoctorName?.toLowerCase().includes(q);
      return matchName || matchId || matchContact || matchDoc;
    }
    return true;
  });

  const departments: Department[] = [
    'Cardiology',
    'General Medicine',
    'Pediatrics',
    'Orthopedics',
    'Neurology',
    'Dermatology',
    'ENT',
    'Gynecology',
    'General Surgery',
    'Ophthalmology',
  ];

  return (
    <div className="space-y-5">
      {/* Control Header */}
      <div className="bg-white border border-slate-200 rounded-lg p-4 sm:p-5 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h1 className="text-lg font-bold text-slate-900 tracking-tight flex items-center gap-2">
              <Users className="w-5 h-5 text-blue-600" />
              <span>Patient Directory & Triage Registry</span>
            </h1>
            <p className="text-xs text-slate-500 mt-1">
              Comprehensive hospital patient records with clinical urgency classifications and assigned consultation details.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onOpenBooking}
              className="px-3.5 py-1.5 text-xs font-semibold bg-blue-600 hover:bg-blue-700 text-white rounded-md transition-colors shadow-xs flex items-center gap-1.5"
            >
              <PlusCircle className="w-4 h-4" />
              <span>+ Book Appointment</span>
            </button>
          </div>
        </div>

        {/* Filter bar */}
        <div className="mt-4 pt-4 border-t border-slate-100 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              placeholder="Search patient name, ID, phone..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-md focus:outline-none focus:ring-1 focus:ring-blue-500 focus:bg-white"
            />
          </div>

          <div>
            <select
              value={selectedDept}
              onChange={(e) => setSelectedDept(e.target.value)}
              className="w-full py-1.5 px-3 text-xs bg-slate-50 border border-slate-200 rounded-md focus:outline-none focus:ring-1 focus:ring-blue-500"
            >
              <option value="All">All Departments</option>
              {departments.map((d) => (
                <option key={d} value={d}>
                  {d}
                </option>
              ))}
            </select>
          </div>

          <div>
            <select
              value={selectedUrgency}
              onChange={(e) => setSelectedUrgency(e.target.value)}
              className="w-full py-1.5 px-3 text-xs bg-slate-50 border border-slate-200 rounded-md focus:outline-none focus:ring-1 focus:ring-blue-500"
            >
              <option value="All">All Urgency Levels</option>
              <option value="Emergency">🔴 Emergency</option>
              <option value="Critical">Critical</option>
              <option value="High">High</option>
              <option value="Normal">Normal</option>
              <option value="Low">Low / Routine</option>
            </select>
          </div>

          <div>
            <select
              value={selectedStatus}
              onChange={(e) => setSelectedStatus(e.target.value)}
              className="w-full py-1.5 px-3 text-xs bg-slate-50 border border-slate-200 rounded-md focus:outline-none focus:ring-1 focus:ring-blue-500"
            >
              <option value="All">All Statuses</option>
              <option value="Confirmed">Confirmed</option>
              <option value="Rescheduled">Rescheduled</option>
              <option value="Waiting List">Waiting List</option>
              <option value="Pending Scheduling">Pending Scheduling</option>
              <option value="Completed">Completed</option>
              <option value="Cancelled">Cancelled</option>
            </select>
          </div>
        </div>
      </div>

      {/* Patient Table */}
      <div className="bg-white border border-slate-200 rounded-lg shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-slate-50/80 border-b border-slate-200 text-slate-600 font-semibold">
                <th className="py-3 px-4">Patient</th>
                <th className="py-3 px-4">Patient ID</th>
                <th className="py-3 px-4">Department</th>
                <th className="py-3 px-4">Assigned Doctor</th>
                <th className="py-3 px-4">Urgency</th>
                <th className="py-3 px-4">Requested Time</th>
                <th className="py-3 px-4">Appointment</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4 text-right">Details</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredPatients.map((p) => {
                const isEmergency = p.urgency === 'Emergency' || p.urgency === 'Critical';

                return (
                  <tr
                    key={p.id}
                    className={`transition-colors ${
                      isEmergency ? 'bg-rose-50/40 hover:bg-rose-50/70' : 'hover:bg-slate-50'
                    }`}
                  >
                    {/* Patient Name */}
                    <td className="py-3 px-4">
                      <div>
                        <span className="font-semibold text-slate-900 block text-sm">
                          {p.patientName}
                        </span>
                        <span className="text-slate-500 text-[11px]">
                          {p.age} yrs · {p.contact}
                        </span>
                      </div>
                    </td>

                    {/* Patient ID */}
                    <td className="py-3 px-4 whitespace-nowrap text-slate-600 font-mono text-[11px]">
                      {p.id}
                    </td>

                    {/* Department */}
                    <td className="py-3 px-4 text-slate-700 font-medium">{p.department}</td>

                    {/* Doctor */}
                    <td className="py-3 px-4 text-slate-900">
                      {p.assignedDoctorName || 'Pending'}
                    </td>

                    {/* Urgency */}
                    <td className="py-3 px-4 whitespace-nowrap">
                      {p.urgency === 'Emergency' ? (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 text-xs font-bold text-rose-800 bg-rose-100 border border-rose-300 rounded shadow-xs">
                          <span>🔴 EMERGENCY</span>
                        </span>
                      ) : p.urgency === 'Critical' ? (
                        <span className="inline-flex items-center px-2 py-0.5 text-xs font-semibold text-rose-700 bg-rose-50 border border-rose-200 rounded">
                          Critical
                        </span>
                      ) : p.urgency === 'High' ? (
                        <span className="inline-flex items-center px-2 py-0.5 text-xs font-semibold text-amber-800 bg-amber-50 border border-amber-200 rounded">
                          High
                        </span>
                      ) : p.urgency === 'Normal' ? (
                        <span className="inline-flex items-center px-2 py-0.5 text-xs text-slate-700 bg-slate-100 rounded">
                          Normal
                        </span>
                      ) : (
                        <span className="inline-flex items-center px-2 py-0.5 text-xs text-slate-500 bg-slate-100 rounded">
                          Routine
                        </span>
                      )}
                    </td>

                    {/* Requested Time */}
                    <td className="py-3 px-4 text-slate-600 whitespace-nowrap">
                      {p.preferredTimeSlot}
                    </td>

                    {/* Appointment */}
                    <td className="py-3 px-4 font-semibold text-slate-800 whitespace-nowrap tabular-nums">
                      {p.appointmentTime}
                    </td>

                    {/* Status */}
                    <td className="py-3 px-4 whitespace-nowrap">
                      <span
                        className={`inline-block px-2 py-0.5 rounded text-[11px] font-medium ${
                          p.status === 'Confirmed'
                            ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                            : p.status === 'Rescheduled'
                            ? 'bg-blue-50 text-blue-700 border border-blue-200'
                            : p.status === 'Waiting List'
                            ? 'bg-amber-50 text-amber-700 border border-amber-200'
                            : p.status === 'Cancelled'
                            ? 'bg-rose-50 text-rose-600 line-through'
                            : 'bg-slate-100 text-slate-700'
                        }`}
                      >
                        {p.status}
                      </span>
                    </td>

                    {/* Details action */}
                    <td className="py-3 px-4 text-right whitespace-nowrap">
                      {p.appointmentRef ? (
                        <button
                          onClick={() => onViewAppointmentDetails(p.appointmentRef!)}
                          className="px-2.5 py-1 text-xs font-medium text-blue-700 hover:text-blue-800 bg-blue-50 hover:bg-blue-100 rounded border border-blue-200 transition-colors inline-flex items-center gap-1"
                        >
                          <HelpCircle className="w-3.5 h-3.5" />
                          <span>Why this slot?</span>
                        </button>
                      ) : (
                        <span className="text-slate-400 text-xs italic">Unscheduled</span>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
