import React, { useState } from 'react';
import { X, HelpCircle, CheckCircle, Clock, Stethoscope, AlertCircle, Code2, ChevronDown, ChevronUp } from 'lucide-react';
import { Appointment } from '../types';

interface WhyAppointmentModalProps {
  appointment: Appointment | null;
  onClose: () => void;
}

export const WhyAppointmentModal: React.FC<WhyAppointmentModalProps> = ({
  appointment,
  onClose,
}) => {
  const [showTechnicalDetails, setShowTechnicalDetails] = useState(false);

  if (!appointment) return null;

  const exp = appointment.selectionExplanation;
  const trace = appointment.algorithmTrace;
  const isEmergency =
    appointment.patientUrgency === 'Emergency' || appointment.patientUrgency === 'Critical';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
      <div className="bg-white rounded-lg border border-slate-200 shadow-xl max-w-lg w-full max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="px-5 py-4 border-b border-slate-200 flex items-center justify-between bg-slate-50/70">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-blue-100 text-blue-700 rounded-md">
              <HelpCircle className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-slate-900">
                Why was this appointment prioritized & selected?
              </h2>
              <p className="text-xs text-slate-500">
                Clinical decision rationale for {appointment.patientName}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded text-slate-400 hover:text-slate-600 hover:bg-slate-100"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 space-y-4 text-xs">
          {/* Patient & Assigned Summary */}
          <div className="p-3 bg-slate-50 border border-slate-200 rounded-lg flex items-center justify-between">
            <div>
              <span className="font-bold text-slate-900 text-sm block">
                {appointment.patientName}
              </span>
              <span className="text-slate-500 text-[11px]">
                {appointment.department} · {appointment.date}
              </span>
            </div>
            <div className="text-right">
              <span className="text-sm font-bold text-blue-700 block tabular-nums">
                {appointment.timeSlot}
              </span>
              <span className="text-slate-600 text-[11px]">{appointment.doctorName}</span>
            </div>
          </div>

          {/* 5 Clinical Explanation Blocks (Medical Terminology) */}
          <div className="space-y-3">
            {/* 1. Priority */}
            <div className="p-3 rounded-lg border border-slate-200 bg-white">
              <div className="flex items-center gap-1.5 text-slate-500 font-semibold mb-1">
                <AlertCircle className={`w-3.5 h-3.5 ${isEmergency ? 'text-rose-600' : 'text-blue-600'}`} />
                <span>Patient Urgency & Triage Level</span>
              </div>
              <p className="text-slate-900 font-medium">
                {exp?.priorityReason || `Priority: ${appointment.patientUrgency} clinical urgency.`}
              </p>
            </div>

            {/* 2. Doctor Specialization */}
            <div className="p-3 rounded-lg border border-slate-200 bg-white">
              <div className="flex items-center gap-1.5 text-slate-500 font-semibold mb-1">
                <Stethoscope className="w-3.5 h-3.5 text-teal-600" />
                <span>Doctor Compatibility</span>
              </div>
              <p className="text-slate-900 font-medium">
                {exp?.doctorReason || `Doctor: Compatible specialist in ${appointment.department} assigned.`}
              </p>
            </div>

            {/* 3. Availability */}
            <div className="p-3 rounded-lg border border-slate-200 bg-white">
              <div className="flex items-center gap-1.5 text-slate-500 font-semibold mb-1">
                <Clock className="w-3.5 h-3.5 text-emerald-600" />
                <span>Doctor Availability</span>
              </div>
              <p className="text-slate-900 font-medium">
                {exp?.availabilityReason || `Availability: Slot available at ${appointment.timeSlot}.`}
              </p>
            </div>

            {/* 4. Patient Preference */}
            <div className="p-3 rounded-lg border border-slate-200 bg-white">
              <div className="flex items-center gap-1.5 text-slate-500 font-semibold mb-1">
                <CheckCircle className="w-3.5 h-3.5 text-indigo-600" />
                <span>Patient Preference</span>
              </div>
              <p className="text-slate-900 font-medium">
                {exp?.preferenceMatch || 'Patient preference: Earliest feasible consultation window.'}
              </p>
            </div>

            {/* 5. Decision Summary */}
            <div className="p-3.5 rounded-lg border border-blue-200 bg-blue-50/70 text-blue-950">
              <span className="font-bold block mb-1">Clinical Decision:</span>
              <p className="font-medium leading-relaxed">
                {exp?.decisionSummary || `${appointment.timeSlot} was the earliest suitable available slot with a compatible doctor.`}
              </p>
            </div>
          </div>

          {/* Collapsible Technical Details (For Evaluation) */}
          <div className="pt-2">
            <button
              onClick={() => setShowTechnicalDetails(!showTechnicalDetails)}
              className="text-[11px] text-slate-500 hover:text-indigo-600 flex items-center gap-1 transition-colors"
            >
              <Code2 className="w-3.5 h-3.5" />
              <span>{showTechnicalDetails ? 'Hide Technical Details' : 'Show Technical / Algorithm Details (DAA)'}</span>
              {showTechnicalDetails ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
            </button>

            {showTechnicalDetails && (
              <div className="mt-2 p-3 bg-slate-900 text-slate-200 rounded font-mono text-[11px] space-y-1.5 overflow-x-auto">
                <div>// DAA Execution Trace Record</div>
                <div>• Patient: {appointment.patientName} (ID: {appointment.patientId})</div>
                <div>• Urgency Level: {appointment.patientUrgency}</div>
                {trace && (
                  <>
                    <div>• Heap Extraction Step: #{trace.queueExtractionOrder}</div>
                    <div>• Candidate Specialists Evaluated: {trace.candidateDoctors.length}</div>
                    <div>• Greedy Rule: {trace.greedyCriterionMet}</div>
                    {trace.tieBreakerUsed && <div>• Tie-Breaker: {trace.tieBreakerUsed}</div>}
                  </>
                )}
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="px-5 py-3 border-t border-slate-200 flex justify-end bg-slate-50/50">
          <button
            onClick={onClose}
            className="px-4 py-1.5 text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-white rounded transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
