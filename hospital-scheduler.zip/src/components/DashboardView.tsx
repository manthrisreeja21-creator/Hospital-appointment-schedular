import React from 'react';
import {
  Users,
  Calendar,
  UserCheck,
  AlertCircle,
  Clock,
  UserX,
  ArrowRight,
  HelpCircle,
  Stethoscope,
  Sparkles,
  CheckCircle2,
} from 'lucide-react';
import { Appointment, Doctor, PatientRequest, RescheduleIncident } from '../types';

interface DashboardViewProps {
  appointments: Appointment[];
  doctors: Doctor[];
  pendingRequests: PatientRequest[];
  waitingList: PatientRequest[];
  latestIncident: RescheduleIncident | null;
  onOpenBooking: () => void;
  onRunAutomaticScheduling: () => void;
  onViewAppointmentDetails: (apt: Appointment) => void;
  onNavigateTab: (tab: string) => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  appointments,
  doctors,
  pendingRequests,
  waitingList,
  latestIncident,
  onOpenBooking,
  onRunAutomaticScheduling,
  onViewAppointmentDetails,
  onNavigateTab,
}) => {
  // Compute metric numbers
  const todayActiveAppointments = appointments.filter(
    (a) => a.status === 'Confirmed' || a.status === 'In Consultation' || a.status === 'Rescheduled'
  );

  const emergencyAppointments = appointments.filter(
    (a) =>
      (a.patientUrgency === 'Emergency' || a.patientUrgency === 'Critical') &&
      a.status !== 'Cancelled'
  );

  const emergencyPendingRequests = [...pendingRequests, ...waitingList].filter(
    (p) => p.urgency === 'Emergency' || p.urgency === 'Critical'
  );

  const availableDoctors = doctors.filter((d) => d.status === 'Available');
  const unavailableDoctors = doctors.filter((d) => d.status === 'Unavailable');

  const totalPatientsCount =
    new Set([
      ...appointments.map((a) => a.patientId),
      ...pendingRequests.map((p) => p.id),
      ...waitingList.map((w) => w.id),
    ]).size;

  const urgentAlertsCount = emergencyPendingRequests.length;

  return (
    <div className="space-y-6">
      {/* Dynamic Urgent Incident Banner if doctor unavailable incident just occurred */}
      {latestIncident && (
        <div className="bg-amber-50 border border-amber-200 rounded-lg p-4 text-amber-900 shadow-sm flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <div className="flex items-start gap-3">
            <div className="p-2 bg-amber-100 rounded-md text-amber-700 mt-0.5">
              <AlertCircle className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-sm font-semibold text-amber-950">
                Doctor Unavailability Incident Handled Automatically
              </h2>
              <p className="text-xs text-amber-800 mt-0.5">
                {latestIncident.unavailableDoctorName} ({latestIncident.department}) became unavailable today.{' '}
                <span className="font-semibold">
                  {latestIncident.successfullyRescheduledCount} affected appointments rescheduled
                </span>{' '}
                to compatible specialists using the priority triage engine.
              </p>
            </div>
          </div>
          <button
            onClick={() => onNavigateTab('schedule')}
            className="px-3 py-1.5 text-xs font-semibold bg-amber-600 hover:bg-amber-700 text-white rounded-md whitespace-nowrap shadow-sm"
          >
            Review Rescheduled
          </button>
        </div>
      )}

      {/* EMERGENCY HIGHLIGHT ALERT: If any emergency cases are pending triage */}
      {urgentAlertsCount > 0 && (
        <div className="bg-rose-50 border-2 border-rose-300 rounded-lg p-4 sm:p-5 shadow-sm text-rose-950">
          <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
            <div className="flex items-start gap-3.5">
              <div className="p-2.5 bg-rose-600 text-white rounded-md flex-shrink-0 animate-pulse">
                <AlertCircle className="w-6 h-6" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold uppercase tracking-wider text-rose-700">
                    🔴 EMERGENCY CASES
                  </span>
                  <span className="text-xs font-medium bg-rose-200 text-rose-900 px-2 py-0.5 rounded">
                    {urgentAlertsCount} Require Immediate Scheduling
                  </span>
                </div>
                <p className="text-sm text-rose-900 mt-1 font-medium">
                  {emergencyPendingRequests.length === 1
                    ? `${emergencyPendingRequests[0].patientName} (${emergencyPendingRequests[0].department}) is waiting for immediate specialist triage.`
                    : `${emergencyPendingRequests.map((p) => p.patientName).slice(0, 3).join(', ')}${
                        emergencyPendingRequests.length > 3
                          ? ` and ${emergencyPendingRequests.length - 3} others`
                          : ''
                      } require urgent clinical slot allocation.`}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2 w-full md:w-auto">
              <button
                onClick={onRunAutomaticScheduling}
                className="w-full md:w-auto px-4 py-2 text-xs font-semibold bg-rose-700 hover:bg-rose-800 text-white rounded-md shadow-sm transition-colors flex items-center justify-center gap-1.5"
              >
                <span>Run Urgent Triage Schedule</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Top 6 Summary KPI Cards */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3 sm:gap-4">
        {/* Total Patients */}
        <div className="bg-white border border-slate-200 rounded-lg p-3.5 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 mb-1">
            <span className="text-xs font-medium">Total Patients</span>
            <Users className="w-4 h-4 text-blue-600" />
          </div>
          <p className="text-2xl font-bold text-slate-900 tabular-nums">
            {totalPatientsCount}
          </p>
          <span className="text-[11px] text-slate-500 mt-0.5 block">
            Across 10 departments
          </span>
        </div>

        {/* Today's Appointments */}
        <div className="bg-white border border-slate-200 rounded-lg p-3.5 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 mb-1">
            <span className="text-xs font-medium">Today's Appointments</span>
            <Calendar className="w-4 h-4 text-emerald-600" />
          </div>
          <p className="text-2xl font-bold text-slate-900 tabular-nums">
            {todayActiveAppointments.length}
          </p>
          <span className="text-[11px] text-emerald-700 font-medium mt-0.5 block">
            {appointments.filter((a) => a.status === 'Confirmed').length} Confirmed
          </span>
        </div>

        {/* Available Doctors */}
        <div className="bg-white border border-slate-200 rounded-lg p-3.5 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 mb-1">
            <span className="text-xs font-medium">Available Doctors</span>
            <UserCheck className="w-4 h-4 text-teal-600" />
          </div>
          <p className="text-2xl font-bold text-slate-900 tabular-nums">
            {availableDoctors.length}
            <span className="text-sm font-normal text-slate-400">/{doctors.length}</span>
          </p>
          <span className="text-[11px] text-teal-700 font-medium mt-0.5 block">
            Ready for consultation
          </span>
        </div>

        {/* Emergency Cases */}
        <div className={`border rounded-lg p-3.5 shadow-xs ${
          emergencyAppointments.length > 0
            ? 'bg-rose-50/70 border-rose-200 text-rose-950'
            : 'bg-white border-slate-200 text-slate-900'
        }`}>
          <div className="flex items-center justify-between text-rose-700 mb-1">
            <span className="text-xs font-bold">Emergency Cases</span>
            <span className="text-rose-600">🔴</span>
          </div>
          <p className="text-2xl font-bold text-rose-700 tabular-nums">
            {emergencyAppointments.length + emergencyPendingRequests.length}
          </p>
          <span className="text-[11px] text-rose-700 font-medium mt-0.5 block">
            {emergencyPendingRequests.length > 0
              ? `${emergencyPendingRequests.length} pending slot`
              : 'All active triaged'}
          </span>
        </div>

        {/* Waiting List */}
        <div className="bg-white border border-slate-200 rounded-lg p-3.5 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 mb-1">
            <span className="text-xs font-medium">Waiting List</span>
            <Clock className="w-4 h-4 text-amber-600" />
          </div>
          <p className="text-2xl font-bold text-slate-900 tabular-nums">
            {waitingList.length + pendingRequests.length}
          </p>
          <span className="text-[11px] text-amber-700 font-medium mt-0.5 block">
            Priority queue queued
          </span>
        </div>

        {/* Doctors Currently Unavailable */}
        <div className="bg-white border border-slate-200 rounded-lg p-3.5 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 mb-1">
            <span className="text-xs font-medium">Unavailable Doctors</span>
            <UserX className="w-4 h-4 text-slate-400" />
          </div>
          <p className="text-2xl font-bold text-slate-900 tabular-nums">
            {unavailableDoctors.length}
          </p>
          <span className="text-[11px] text-slate-500 mt-0.5 block">
            {unavailableDoctors.length === 0 ? 'Full staff on duty' : 'Covered by peers'}
          </span>
        </div>
      </div>

      {/* Main Grid: Today's Appointments & Right Sidebar (Doctor Availability + Quick Actions) */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column (2 Cols on lg): Today's Schedule Overview */}
        <div className="lg:col-span-2 space-y-4">
          <div className="bg-white border border-slate-200 rounded-lg shadow-xs overflow-hidden">
            <div className="px-5 py-3.5 border-b border-slate-200 flex items-center justify-between bg-slate-50/50">
              <div>
                <h2 className="text-sm font-semibold text-slate-900">
                  Today's Appointments Timeline
                </h2>
                <p className="text-xs text-slate-500">
                  Organized chronologically by appointment priority and doctor roster
                </p>
              </div>
              <button
                onClick={() => onNavigateTab('schedule')}
                className="text-xs text-blue-600 hover:text-blue-700 font-medium flex items-center gap-1"
              >
                <span>View Full Schedule</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* List of Today's appointments */}
            <div className="divide-y divide-slate-100 max-h-[480px] overflow-y-auto">
              {todayActiveAppointments.length === 0 ? (
                <div className="p-8 text-center text-slate-400">
                  <p className="text-sm">No scheduled appointments for today yet.</p>
                  <button
                    onClick={onRunAutomaticScheduling}
                    className="mt-3 px-3 py-1.5 text-xs bg-blue-600 text-white rounded-md"
                  >
                    Run Automatic Scheduling
                  </button>
                </div>
              ) : (
                todayActiveAppointments.slice(0, 10).map((apt) => {
                  const isEmergency =
                    apt.patientUrgency === 'Emergency' || apt.patientUrgency === 'Critical';

                  return (
                    <div
                      key={apt.id}
                      className={`px-5 py-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-3 transition-colors ${
                        isEmergency ? 'bg-rose-50/40 hover:bg-rose-50/70' : 'hover:bg-slate-50'
                      }`}
                    >
                      <div className="flex items-start gap-3">
                        <div
                          className={`w-14 text-center py-1 rounded text-xs font-bold tabular-nums flex-shrink-0 ${
                            isEmergency
                              ? 'bg-rose-600 text-white shadow-xs'
                              : 'bg-slate-100 text-slate-800'
                          }`}
                        >
                          {apt.timeSlot}
                        </div>
                        <div>
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className="text-sm font-semibold text-slate-900">
                              {apt.patientName}
                            </span>
                            <span className="text-xs text-slate-500 font-normal">
                              ({apt.patientAge}y · {apt.patientContact})
                            </span>
                            {isEmergency ? (
                              <span className="text-[11px] font-bold text-rose-700 bg-rose-100 px-2 py-0.2 rounded border border-rose-200">
                                🔴 {apt.patientUrgency.toUpperCase()}
                              </span>
                            ) : apt.patientUrgency === 'High' ? (
                              <span className="text-[11px] font-semibold text-amber-700 bg-amber-50 px-2 py-0.2 rounded border border-amber-200">
                                High Priority
                              </span>
                            ) : (
                              <span className="text-[11px] text-slate-600 bg-slate-100 px-2 py-0.2 rounded">
                                {apt.patientUrgency}
                              </span>
                            )}
                          </div>
                          <div className="text-xs text-slate-600 mt-1 flex items-center gap-1.5 flex-wrap">
                            <span className="font-medium text-slate-900">{apt.doctorName}</span>
                            <span className="text-slate-400">·</span>
                            <span>{apt.department}</span>
                            <span className="text-slate-400">·</span>
                            <span
                              className={`px-1.5 py-0.2 rounded text-[10px] font-medium ${
                                apt.status === 'Confirmed'
                                  ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                                  : apt.status === 'Rescheduled'
                                  ? 'bg-blue-50 text-blue-700 border border-blue-200'
                                  : 'bg-slate-100 text-slate-700'
                              }`}
                            >
                              {apt.status}
                            </span>
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center gap-2 sm:self-center">
                        <button
                          onClick={() => onViewAppointmentDetails(apt)}
                          className="px-2.5 py-1 text-xs font-medium text-blue-700 hover:text-blue-800 bg-blue-50 hover:bg-blue-100 rounded border border-blue-200 transition-colors flex items-center gap-1"
                          title="View clinical rationale for selecting this appointment"
                        >
                          <HelpCircle className="w-3.5 h-3.5" />
                          <span>Why this appointment?</span>
                        </button>
                      </div>
                    </div>
                  );
                })
              )}
            </div>

            {todayActiveAppointments.length > 10 && (
              <div className="px-5 py-2.5 bg-slate-50 border-t border-slate-200 text-center">
                <button
                  onClick={() => onNavigateTab('schedule')}
                  className="text-xs font-medium text-blue-600 hover:underline"
                >
                  +{todayActiveAppointments.length - 10} more appointments in live schedule →
                </button>
              </div>
            )}
          </div>

          {/* Pending Triage Queue Card */}
          {pendingRequests.length > 0 && (
            <div className="bg-white border border-slate-200 rounded-lg p-4 shadow-xs">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <h3 className="text-sm font-semibold text-slate-900">
                    Pending Appointment Requests Awaiting Scheduler
                  </h3>
                  <span className="text-xs bg-amber-100 text-amber-800 font-semibold px-2 py-0.5 rounded-full">
                    {pendingRequests.length} pending
                  </span>
                </div>
                <button
                  onClick={onRunAutomaticScheduling}
                  className="px-3 py-1 text-xs font-semibold bg-blue-600 hover:bg-blue-700 text-white rounded transition-colors"
                >
                  Run Scheduling Now
                </button>
              </div>

              <div className="space-y-2">
                {pendingRequests.slice(0, 4).map((p) => (
                  <div
                    key={p.id}
                    className="p-2.5 bg-slate-50 border border-slate-200 rounded flex items-center justify-between text-xs"
                  >
                    <div>
                      <span className="font-semibold text-slate-900">{p.patientName}</span>
                      <span className="text-slate-500 ml-2">
                        {p.department} · {p.preferredTimeSlot || 'Any slot'}
                      </span>
                    </div>
                    <div>
                      {p.urgency === 'Emergency' ? (
                        <span className="text-rose-700 font-bold bg-rose-100 px-2 py-0.5 rounded">
                          🔴 Emergency
                        </span>
                      ) : p.urgency === 'Critical' ? (
                        <span className="text-rose-600 font-semibold bg-rose-50 px-2 py-0.5 rounded">
                          Critical
                        </span>
                      ) : (
                        <span className="text-slate-600 bg-white px-2 py-0.5 rounded border border-slate-200">
                          {p.urgency}
                        </span>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Right Column: Doctor Availability Overview & Quick System Actions */}
        <div className="space-y-4">
          {/* Doctor Availability Snapshot */}
          <div className="bg-white border border-slate-200 rounded-lg shadow-xs overflow-hidden">
            <div className="px-4 py-3 border-b border-slate-200 flex items-center justify-between bg-slate-50/50">
              <div className="flex items-center gap-2">
                <Stethoscope className="w-4 h-4 text-teal-600" />
                <h3 className="text-sm font-semibold text-slate-900">
                  Doctor Availability Overview
                </h3>
              </div>
              <button
                onClick={() => onNavigateTab('doctors')}
                className="text-xs text-teal-700 hover:underline font-medium"
              >
                All 24 Doctors
              </button>
            </div>

            <div className="p-3 divide-y divide-slate-100 max-h-[360px] overflow-y-auto">
              {doctors.slice(0, 7).map((doc) => {
                const docAppointments = appointments.filter(
                  (a) => a.doctorId === doc.id && a.status !== 'Cancelled'
                ).length;
                return (
                  <div key={doc.id} className="py-2.5 flex items-center justify-between text-xs">
                    <div>
                      <p className="font-semibold text-slate-900">{doc.name}</p>
                      <p className="text-slate-500 text-[11px]">
                        {doc.department} · {doc.roomNumber}
                      </p>
                    </div>
                    <div className="text-right">
                      <span
                        className={`inline-block px-2 py-0.5 rounded text-[10px] font-semibold ${
                          doc.status === 'Available'
                            ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                            : doc.status === 'In Consultation'
                            ? 'bg-blue-50 text-blue-700 border border-blue-200'
                            : doc.status === 'On Break'
                            ? 'bg-amber-50 text-amber-700 border border-amber-200'
                            : 'bg-slate-100 text-slate-500 border border-slate-200'
                        }`}
                      >
                        {doc.status}
                      </span>
                      <span className="block text-[10px] text-slate-400 mt-0.5 tabular-nums">
                        {docAppointments}/{doc.maxDailyCapacity} slots filled
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>

            <div className="p-3 bg-slate-50 border-t border-slate-200">
              <button
                onClick={() => onNavigateTab('doctors')}
                className="w-full py-1.5 text-xs font-semibold text-slate-700 bg-white hover:bg-slate-100 border border-slate-300 rounded text-center transition-colors"
              >
                Manage Rosters & Test Doctor Unavailability
              </button>
            </div>
          </div>

          {/* Quick Actions & Demo Prompts */}
          <div className="bg-gradient-to-br from-slate-900 to-blue-950 text-white rounded-lg p-4 shadow-sm space-y-3">
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-blue-400" />
              <h3 className="text-sm font-semibold">Hospital Scheduling Engine</h3>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              Appointments are triaged dynamically: medical emergency cases are prioritized first,
              doctor workload is balanced, and earliest feasible clinical consultation slots are
              assigned without patient delay.
            </p>

            <div className="pt-2 flex flex-col gap-2">
              <button
                onClick={onOpenBooking}
                className="w-full py-2 px-3 text-xs font-semibold bg-blue-600 hover:bg-blue-500 rounded text-white text-center shadow-xs transition-colors"
              >
                + Register & Book New Patient
              </button>

              <button
                onClick={() => onNavigateTab('algorithms')}
                className="w-full py-2 px-3 text-xs font-medium bg-slate-800/80 hover:bg-slate-800 border border-slate-700 rounded text-slate-200 text-center transition-colors"
              >
                View Technical / Algorithm Evaluation Details →
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
