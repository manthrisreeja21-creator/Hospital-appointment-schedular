import React, { useState } from 'react';
import {
  Calendar,
  Search,
  Filter,
  CheckCircle,
  XCircle,
  UserX,
  HelpCircle,
  RefreshCw,
  Clock,
  ChevronDown,
} from 'lucide-react';
import { Appointment, Department, Doctor, UrgencyLevel, AppointmentStatus } from '../types';

interface ScheduleViewProps {
  appointments: Appointment[];
  doctors: Doctor[];
  onViewAppointmentDetails: (apt: Appointment) => void;
  onCancelAppointment: (appointmentId: string) => void;
  onMarkNoShow: (appointmentId: string) => void;
  onMarkCompleted: (appointmentId: string) => void;
  onOpenBooking: () => void;
}

export const ScheduleView: React.FC<ScheduleViewProps> = ({
  appointments,
  doctors,
  onViewAppointmentDetails,
  onCancelAppointment,
  onMarkNoShow,
  onMarkCompleted,
  onOpenBooking,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedDept, setSelectedDept] = useState<string>('All');
  const [selectedDoctorId, setSelectedDoctorId] = useState<string>('All');
  const [selectedUrgency, setSelectedUrgency] = useState<string>('All');
  const [selectedStatus, setSelectedStatus] = useState<string>('All');

  // Filter appointments
  const filteredAppointments = appointments.filter((apt) => {
    if (selectedDept !== 'All' && apt.department !== selectedDept) return false;
    if (selectedDoctorId !== 'All' && apt.doctorId !== selectedDoctorId) return false;
    if (selectedUrgency !== 'All' && apt.patientUrgency !== selectedUrgency) return false;
    if (selectedStatus !== 'All' && apt.status !== selectedStatus) return false;

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchName = apt.patientName.toLowerCase().includes(q);
      const matchDoc = apt.doctorName.toLowerCase().includes(q);
      const matchId = apt.patientId.toLowerCase().includes(q);
      const matchSlot = apt.timeSlot.includes(q);
      return matchName || matchDoc || matchId || matchSlot;
    }
    return true;
  });

  // Sort chronologically by timeSlot
  const sortedFilteredAppointments = [...filteredAppointments].sort((a, b) => {
    // If times are different
    if (a.timeSlot !== b.timeSlot) {
      return a.timeSlot.localeCompare(b.timeSlot);
    }
    // Then by urgency
    const urgencyOrder: Record<UrgencyLevel, number> = {
      Emergency: 1,
      Critical: 2,
      High: 3,
      Normal: 4,
      Low: 5,
    };
    return urgencyOrder[a.patientUrgency] - urgencyOrder[b.patientUrgency];
  });

  const departments: Department[] = [
    'Cardiology',
    'General Medicine',
    'Pediatrics',
    'Orthopedics',
    'Neurology',
    'Dermatology',
    'ENT',
    'Gynecology',
    'General Surgery',
    'Ophthalmology',
  ];

  return (
    <div className="space-y-5">
      {/* Top Banner & Control Bar */}
      <div className="bg-white border border-slate-200 rounded-lg p-4 sm:p-5 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h1 className="text-lg font-bold text-slate-900 tracking-tight flex items-center gap-2">
              <Calendar className="w-5 h-5 text-blue-600" />
              <span>Hospital Live Appointment Schedule</span>
            </h1>
            <p className="text-xs text-slate-500 mt-1">
              Active schedule dynamically coordinated by patient urgency, doctor specialization, and available time slots.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onOpenBooking}
              className="px-3 py-1.5 text-xs font-semibold bg-blue-600 hover:bg-blue-700 text-white rounded-md transition-colors shadow-xs"
            >
              + New Appointment
            </button>
          </div>
        </div>

        {/* Filter Controls Row */}
        <div className="mt-4 pt-4 border-t border-slate-100 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
          {/* Search box */}
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              placeholder="Search patient, doctor, ID..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-md focus:outline-none focus:ring-1 focus:ring-blue-500 focus:bg-white"
            />
          </div>

          {/* Department Filter */}
          <div>
            <select
              value={selectedDept}
              onChange={(e) => setSelectedDept(e.target.value)}
              className="w-full py-1.5 px-2.5 text-xs bg-slate-50 border border-slate-200 rounded-md focus:outline-none focus:ring-1 focus:ring-blue-500"
            >
              <option value="All">All Departments</option>
              {departments.map((dept) => (
                <option key={dept} value={dept}>
                  {dept}
                </option>
              ))}
            </select>
          </div>

          {/* Doctor Filter */}
          <div>
            <select
              value={selectedDoctorId}
              onChange={(e) => setSelectedDoctorId(e.target.value)}
              className="w-full py-1.5 px-2.5 text-xs bg-slate-50 border border-slate-200 rounded-md focus:outline-none focus:ring-1 focus:ring-blue-500"
            >
              <option value="All">All Doctors</option>
              {doctors.map((d) => (
                <option key={d.id} value={d.id}>
                  {d.name} ({d.department})
                </option>
              ))}
            </select>
          </div>

          {/* Urgency Filter */}
          <div>
            <select
              value={selectedUrgency}
              onChange={(e) => setSelectedUrgency(e.target.value)}
              className="w-full py-1.5 px-2.5 text-xs bg-slate-50 border border-slate-200 rounded-md focus:outline-none focus:ring-1 focus:ring-blue-500"
            >
              <option value="All">All Urgency Tiers</option>
              <option value="Emergency">🔴 Emergency</option>
              <option value="Critical">Critical</option>
              <option value="High">High Priority</option>
              <option value="Normal">Normal</option>
              <option value="Low">Low / Routine</option>
            </select>
          </div>

          {/* Status Filter */}
          <div>
            <select
              value={selectedStatus}
              onChange={(e) => setSelectedStatus(e.target.value)}
              className="w-full py-1.5 px-2.5 text-xs bg-slate-50 border border-slate-200 rounded-md focus:outline-none focus:ring-1 focus:ring-blue-500"
            >
              <option value="All">All Statuses</option>
              <option value="Confirmed">Confirmed</option>
              <option value="Rescheduled">Rescheduled</option>
              <option value="Completed">Completed</option>
              <option value="Cancelled">Cancelled</option>
              <option value="No Show">No Show</option>
            </select>
          </div>
        </div>
      </div>

      {/* Appointment Count Banner */}
      <div className="flex items-center justify-between text-xs text-slate-500 px-1">
        <span>
          Showing <strong className="text-slate-800">{sortedFilteredAppointments.length}</strong> of{' '}
          {appointments.length} appointments
        </span>
        <div className="flex items-center gap-3">
          <span className="flex items-center gap-1">
            <span className="w-2.5 h-2.5 rounded-full bg-rose-600 inline-block"></span>
            <span>Emergency / Critical</span>
          </span>
          <span className="flex items-center gap-1">
            <span className="w-2.5 h-2.5 rounded-full bg-blue-600 inline-block"></span>
            <span>Rescheduled</span>
          </span>
          <span className="flex items-center gap-1">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-600 inline-block"></span>
            <span>Confirmed</span>
          </span>
        </div>
      </div>

      {/* Main Appointments Table / Timeline Cards */}
      <div className="bg-white border border-slate-200 rounded-lg shadow-xs overflow-hidden">
        {sortedFilteredAppointments.length === 0 ? (
          <div className="p-12 text-center text-slate-400">
            <p className="text-sm font-medium">No appointments match the selected filter criteria.</p>
            <button
              onClick={() => {
                setSelectedDept('All');
                setSelectedDoctorId('All');
                setSelectedUrgency('All');
                setSelectedStatus('All');
                setSearchQuery('');
              }}
              className="mt-3 text-xs text-blue-600 hover:underline font-semibold"
            >
              Reset all filters
            </button>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-slate-50/80 border-b border-slate-200 text-slate-600 font-semibold">
                  <th className="py-3 px-4">Time Slot</th>
                  <th className="py-3 px-4">Patient Details</th>
                  <th className="py-3 px-4">Assigned Doctor & Dept</th>
                  <th className="py-3 px-4">Urgency Level</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {sortedFilteredAppointments.map((apt) => {
                  const isEmergency =
                    apt.patientUrgency === 'Emergency' || apt.patientUrgency === 'Critical';

                  return (
                    <tr
                      key={apt.id}
                      className={`transition-colors ${
                        apt.status === 'Cancelled'
                          ? 'bg-slate-50/50 opacity-60'
                          : isEmergency
                          ? 'bg-rose-50/30 hover:bg-rose-50/60'
                          : 'hover:bg-slate-50/80'
                      }`}
                    >
                      {/* Time Slot */}
                      <td className="py-3 px-4 whitespace-nowrap">
                        <div className="flex items-center gap-2">
                          <span
                            className={`px-2.5 py-1 rounded text-xs font-bold tabular-nums ${
                              isEmergency
                                ? 'bg-rose-600 text-white'
                                : 'bg-slate-100 text-slate-800'
                            }`}
                          >
                            {apt.timeSlot}
                          </span>
                          <span className="text-[11px] text-slate-400">{apt.date}</span>
                        </div>
                      </td>

                      {/* Patient Details */}
                      <td className="py-3 px-4">
                        <div>
                          <p className="font-semibold text-slate-900 text-sm">
                            {apt.patientName}
                          </p>
                          <p className="text-slate-500 text-[11px]">
                            ID: {apt.patientId} · {apt.patientAge} yrs · {apt.patientContact}
                          </p>
                        </div>
                      </td>

                      {/* Doctor & Dept */}
                      <td className="py-3 px-4">
                        <div>
                          <p className="font-semibold text-slate-900">{apt.doctorName}</p>
                          <p className="text-slate-500 text-[11px]">{apt.department}</p>
                          {apt.rescheduledFromDoctorId && (
                            <span className="text-[10px] text-blue-700 font-medium bg-blue-50 px-1.5 py-0.2 rounded border border-blue-200 block mt-0.5 max-w-fit">
                              Rescheduled from alternate doctor
                            </span>
                          )}
                        </div>
                      </td>

                      {/* Urgency Badge */}
                      <td className="py-3 px-4 whitespace-nowrap">
                        {apt.patientUrgency === 'Emergency' ? (
                          <span className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-bold text-rose-800 bg-rose-100 border border-rose-300 rounded shadow-xs">
                            <span>🔴 EMERGENCY</span>
                          </span>
                        ) : apt.patientUrgency === 'Critical' ? (
                          <span className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-semibold text-rose-700 bg-rose-50 border border-rose-200 rounded">
                            <span>Critical Case</span>
                          </span>
                        ) : apt.patientUrgency === 'High' ? (
                          <span className="inline-flex items-center px-2 py-0.5 text-xs font-semibold text-amber-800 bg-amber-50 border border-amber-200 rounded">
                            High Priority
                          </span>
                        ) : apt.patientUrgency === 'Normal' ? (
                          <span className="inline-flex items-center px-2 py-0.5 text-xs text-slate-700 bg-slate-100 rounded">
                            Normal
                          </span>
                        ) : (
                          <span className="inline-flex items-center px-2 py-0.5 text-xs text-slate-500 bg-slate-100 rounded">
                            Low / Routine
                          </span>
                        )}
                      </td>

                      {/* Status */}
                      <td className="py-3 px-4 whitespace-nowrap">
                        <span
                          className={`inline-block px-2.5 py-1 rounded text-xs font-semibold ${
                            apt.status === 'Confirmed'
                              ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                              : apt.status === 'Rescheduled'
                              ? 'bg-blue-50 text-blue-700 border border-blue-200'
                              : apt.status === 'Completed'
                              ? 'bg-slate-100 text-slate-700 border border-slate-300'
                              : apt.status === 'Cancelled'
                              ? 'bg-rose-50 text-rose-600 line-through border border-rose-200'
                              : 'bg-amber-50 text-amber-700 border border-amber-200'
                          }`}
                        >
                          {apt.status}
                        </span>
                      </td>

                      {/* Actions */}
                      <td className="py-3 px-4 text-right whitespace-nowrap">
                        <div className="flex items-center justify-end gap-1.5">
                          {/* "Why this appointment?" clinical explanation modal */}
                          <button
                            onClick={() => onViewAppointmentDetails(apt)}
                            className="px-2.5 py-1 text-xs font-medium text-blue-700 hover:text-blue-800 bg-blue-50 hover:bg-blue-100 rounded border border-blue-200 transition-colors flex items-center gap-1"
                            title="Show clinical selection explanation"
                          >
                            <HelpCircle className="w-3.5 h-3.5" />
                            <span>Why this appointment?</span>
                          </button>

                          {apt.status === 'Confirmed' || apt.status === 'Rescheduled' ? (
                            <>
                              <button
                                onClick={() => onMarkCompleted(apt.id)}
                                className="p-1 text-emerald-600 hover:text-emerald-800 hover:bg-emerald-50 rounded"
                                title="Mark Consultation Completed"
                              >
                                <CheckCircle className="w-4 h-4" />
                              </button>
                              <button
                                onClick={() => onMarkNoShow(apt.id)}
                                className="p-1 text-amber-600 hover:text-amber-800 hover:bg-amber-50 rounded"
                                title="Mark Patient No-Show"
                              >
                                <UserX className="w-4 h-4" />
                              </button>
                              <button
                                onClick={() => onCancelAppointment(apt.id)}
                                className="p-1 text-rose-500 hover:text-rose-700 hover:bg-rose-50 rounded"
                                title="Cancel Appointment (Automatically frees slot for waiting triage)"
                              >
                                <XCircle className="w-4 h-4" />
                              </button>
                            </>
                          ) : null}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
