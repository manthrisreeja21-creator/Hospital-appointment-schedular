import React, { useState } from 'react';
import { X, Calendar, AlertCircle, CheckCircle2 } from 'lucide-react';
import { Department, Doctor, UrgencyLevel, PatientRequest, ALL_STANDARD_SLOTS } from '../types';
import { TODAY_DATE } from '../data/seedData';

interface BookAppointmentModalProps {
  isOpen: boolean;
  onClose: () => void;
  doctors: Doctor[];
  onSubmitBooking: (request: Omit<PatientRequest, 'id' | 'requestTimestamp' | 'status'>) => void;
}

export const BookAppointmentModal: React.FC<BookAppointmentModalProps> = ({
  isOpen,
  onClose,
  doctors,
  onSubmitBooking,
}) => {
  const [patientName, setPatientName] = useState('');
  const [age, setAge] = useState<number>(35);
  const [gender, setGender] = useState<'Male' | 'Female' | 'Other'>('Male');
  const [contact, setContact] = useState('');
  const [department, setDepartment] = useState<Department>('Cardiology');
  const [preferredDoctorId, setPreferredDoctorId] = useState<string>('');
  const [urgency, setUrgency] = useState<UrgencyLevel>('Normal');
  const [preferredDate, setPreferredDate] = useState(TODAY_DATE);
  const [preferredTimeSlot, setPreferredTimeSlot] = useState('Morning (09:00 - 12:00)');
  const [symptoms, setSymptoms] = useState('');
  const [errorMsg, setErrorMsg] = useState('');

  if (!isOpen) return null;

  const departments: Department[] = [
    'Cardiology',
    'General Medicine',
    'Pediatrics',
    'Orthopedics',
    'Neurology',
    'Dermatology',
    'ENT',
    'Gynecology',
    'General Surgery',
    'Ophthalmology',
  ];

  const availableDocsInDept = doctors.filter(
    (d) => d.department === department && d.status !== 'Unavailable'
  );

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!patientName.trim()) {
      setErrorMsg('Please enter the patient name.');
      return;
    }
    if (!contact.trim()) {
      setErrorMsg('Please enter a contact number.');
      return;
    }

    setErrorMsg('');
    onSubmitBooking({
      patientName: patientName.trim(),
      age: Number(age) || 30,
      gender,
      contact: contact.trim(),
      department,
      preferredDoctorId: preferredDoctorId || undefined,
      urgency,
      preferredDate,
      preferredTimeSlot,
      symptoms: symptoms.trim() || 'General consultation requested',
    });

    // Reset fields
    setPatientName('');
    setContact('');
    setSymptoms('');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
      <div className="bg-white rounded-lg border border-slate-200 shadow-xl max-w-lg w-full max-h-[90vh] overflow-y-auto">
        {/* Modal Header */}
        <div className="px-5 py-4 border-b border-slate-200 flex items-center justify-between bg-slate-50/60">
          <div>
            <h2 className="text-base font-bold text-slate-900">
              Register Patient & Book Appointment
            </h2>
            <p className="text-xs text-slate-500">
              Request will enter the hospital triage and priority scheduling pipeline.
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded text-slate-400 hover:text-slate-600 hover:bg-slate-100"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body / Form */}
        <form onSubmit={handleSubmit} className="p-5 space-y-4 text-xs">
          {errorMsg && (
            <div className="p-2.5 bg-rose-50 border border-rose-200 text-rose-700 rounded flex items-center gap-2">
              <AlertCircle className="w-4 h-4 flex-shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          {/* Patient Name & Age */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="sm:col-span-2">
              <label className="block text-slate-700 font-semibold mb-1">
                Patient Full Name *
              </label>
              <input
                type="text"
                required
                placeholder="e.g. Ramesh Chandra"
                value={patientName}
                onChange={(e) => setPatientName(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded focus:bg-white focus:outline-none focus:ring-1 focus:ring-blue-500 text-xs"
              />
            </div>
            <div>
              <label className="block text-slate-700 font-semibold mb-1">Age *</label>
              <input
                type="number"
                min="0"
                max="120"
                required
                value={age}
                onChange={(e) => setAge(parseInt(e.target.value, 10))}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded focus:bg-white focus:outline-none focus:ring-1 focus:ring-blue-500 text-xs"
              />
            </div>
          </div>

          {/* Gender & Contact */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-slate-700 font-semibold mb-1">Gender</label>
              <select
                value={gender}
                onChange={(e) => setGender(e.target.value as any)}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded focus:outline-none focus:ring-1 focus:ring-blue-500 text-xs"
              >
                <option value="Male">Male</option>
                <option value="Female">Female</option>
                <option value="Other">Other</option>
              </select>
            </div>
            <div>
              <label className="block text-slate-700 font-semibold mb-1">
                Contact Phone *
              </label>
              <input
                type="tel"
                required
                placeholder="+91 98XXX XXXXX"
                value={contact}
                onChange={(e) => setContact(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded focus:bg-white focus:outline-none focus:ring-1 focus:ring-blue-500 text-xs"
              />
            </div>
          </div>

          {/* Department & Doctor Preference */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-slate-700 font-semibold mb-1">
                Medical Department *
              </label>
              <select
                value={department}
                onChange={(e) => {
                  setDepartment(e.target.value as Department);
                  setPreferredDoctorId('');
                }}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded focus:outline-none focus:ring-1 focus:ring-blue-500 text-xs"
              >
                {departments.map((dept) => (
                  <option key={dept} value={dept}>
                    {dept}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-slate-700 font-semibold mb-1">
                Physician Preference (Optional)
              </label>
              <select
                value={preferredDoctorId}
                onChange={(e) => setPreferredDoctorId(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded focus:outline-none focus:ring-1 focus:ring-blue-500 text-xs"
              >
                <option value="">Any Available Specialist</option>
                {availableDocsInDept.map((doc) => (
                  <option key={doc.id} value={doc.id}>
                    {doc.name}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Urgency Level Selector */}
          <div>
            <label className="block text-slate-700 font-semibold mb-1">
              Patient Urgency / Triage Level *
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-5 gap-1.5">
              {(['Emergency', 'Critical', 'High', 'Normal', 'Low'] as UrgencyLevel[]).map((level) => {
                const isSelected = urgency === level;
                return (
                  <button
                    type="button"
                    key={level}
                    onClick={() => setUrgency(level)}
                    className={`py-2 px-1 text-center rounded border text-xs font-semibold transition-colors ${
                      isSelected
                        ? level === 'Emergency'
                          ? 'bg-rose-600 text-white border-rose-700 shadow-xs'
                          : level === 'Critical'
                          ? 'bg-rose-500 text-white border-rose-600 shadow-xs'
                          : level === 'High'
                          ? 'bg-amber-600 text-white border-amber-700 shadow-xs'
                          : 'bg-blue-600 text-white border-blue-700 shadow-xs'
                        : level === 'Emergency'
                        ? 'bg-rose-50 text-rose-700 border-rose-200 hover:bg-rose-100'
                        : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                    }`}
                  >
                    {level === 'Emergency' ? '🔴 Emergency' : level}
                  </button>
                );
              })}
            </div>
            <p className="text-[11px] text-slate-500 mt-1">
              Emergency & Critical cases are triaged to the root of the Priority Queue for immediate slot allocation.
            </p>
          </div>

          {/* Preferred Date & Preferred Time */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-slate-700 font-semibold mb-1">Preferred Date</label>
              <input
                type="date"
                value={preferredDate}
                onChange={(e) => setPreferredDate(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded focus:outline-none focus:ring-1 focus:ring-blue-500 text-xs"
              />
            </div>
            <div>
              <label className="block text-slate-700 font-semibold mb-1">Preferred Time Window</label>
              <select
                value={preferredTimeSlot}
                onChange={(e) => setPreferredTimeSlot(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded focus:outline-none focus:ring-1 focus:ring-blue-500 text-xs"
              >
                <option value="Morning (09:00 - 12:00)">Morning (09:00 - 12:00)</option>
                <option value="Afternoon (13:00 - 16:30)">Afternoon (13:00 - 16:30)</option>
                {ALL_STANDARD_SLOTS.map((slot) => (
                  <option key={slot} value={slot}>
                    Exact Slot: {slot}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Symptoms / Clinical Notes */}
          <div>
            <label className="block text-slate-700 font-semibold mb-1">
              Symptoms / Medical Reason
            </label>
            <textarea
              rows={2}
              placeholder="Describe clinical symptoms or reason for urgency..."
              value={symptoms}
              onChange={(e) => setSymptoms(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded focus:bg-white focus:outline-none focus:ring-1 focus:ring-blue-500 text-xs"
            ></textarea>
          </div>

          {/* Footer Actions */}
          <div className="pt-3 border-t border-slate-200 flex items-center justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 text-xs font-semibold bg-blue-600 hover:bg-blue-500 text-white rounded shadow-xs transition-colors"
            >
              BOOK APPOINTMENT
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
