import React, { useState } from 'react';
import {
  Code2,
  GitBranch,
  Layers,
  Database,
  Cpu,
  RefreshCw,
  Terminal,
  Server,
} from 'lucide-react';
import {
  Appointment,
  PatientRequest,
  Doctor,
} from '../types';

interface AlgorithmDetailsViewProps {
  executionData: any;
  appointments: Appointment[];
  pendingRequests: PatientRequest[];
  doctors: Doctor[];
  onReRunScheduling: () => void;
  isBackendLoading?: boolean;
}

export const AlgorithmDetailsView: React.FC<AlgorithmDetailsViewProps> = ({
  executionData,
  appointments,
  pendingRequests,
  doctors,
  onReRunScheduling,
  isBackendLoading = false,
}) => {
  const [activeSubTab, setActiveSubTab] = useState<'pipeline' | 'trace' | 'heap' | 'complexity'>(
    'pipeline'
  );
  const [selectedTraceStepIndex, setSelectedTraceStepIndex] = useState<number>(0);

  const sortingTrace = executionData?.sorting;
  const greedySteps = executionData?.greedy_steps || [];
  const pqExtractions = executionData?.priority_queue_extractions || executionData?.priority_queue_steps || [];
  const pqInsertions = executionData?.priority_queue_insertions || [];

  const currentStep =
    greedySteps.length > 0 && selectedTraceStepIndex < greedySteps.length
      ? greedySteps[selectedTraceStepIndex]
      : null;

  return (
    <div className="space-y-6">
      {/* Header Banner for Project Evaluator */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 text-white shadow-sm">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="px-2 py-0.5 text-[10px] font-bold tracking-wider uppercase bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 rounded flex items-center gap-1">
                <Server className="w-3 h-3 text-emerald-400" />
                Python 3.10 Backend DAA Engine
              </span>
              <span className="text-xs text-slate-400">Design & Analysis of Algorithms</span>
            </div>
            <h1 className="text-xl font-bold tracking-tight text-white mt-1 flex items-center gap-2">
              <Code2 className="w-5 h-5 text-indigo-400" />
              <span>Python DAA Backend Execution & Algorithm Replay</span>
            </h1>
            <p className="text-xs text-slate-300 mt-1 max-w-3xl leading-relaxed">
              This panel verifies the genuine algorithmic engine running in the <strong>Python backend</strong>.
              All patient triage ordering (<code className="text-blue-300">sorting.py</code>), Priority Queue state transitions (<code className="text-indigo-300">priority_queue.py</code> with <code className="text-indigo-300">heapq</code>),
              and greedy doctor/slot allocations (<code className="text-teal-300">greedy_scheduler.py</code>) are computed by Python and received via JSON API.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onReRunScheduling}
              disabled={isBackendLoading}
              className="px-3.5 py-2 text-xs font-semibold bg-indigo-600 hover:bg-indigo-500 disabled:bg-slate-700 text-white rounded-md transition-colors shadow-xs flex items-center gap-1.5 whitespace-nowrap"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isBackendLoading ? 'animate-spin' : ''}`} />
              <span>{isBackendLoading ? 'Calling Python API...' : 'Re-Run Python Scheduler'}</span>
            </button>
          </div>
        </div>

        {/* Algorithm Sub-navigation */}
        <div className="mt-5 pt-4 border-t border-slate-800 flex items-center gap-2 overflow-x-auto scrollbar-none">
          <button
            onClick={() => setActiveSubTab('pipeline')}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap flex items-center gap-1.5 ${
              activeSubTab === 'pipeline'
                ? 'bg-indigo-600 text-white shadow-xs'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <GitBranch className="w-3.5 h-3.5" />
            <span>1. Pipeline Architecture (Python)</span>
          </button>

          <button
            onClick={() => setActiveSubTab('trace')}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap flex items-center gap-1.5 ${
              activeSubTab === 'trace'
                ? 'bg-indigo-600 text-white shadow-xs'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            <span>2. Step-by-Step Python Execution Trace ({greedySteps.length} Steps)</span>
          </button>

          <button
            onClick={() => setActiveSubTab('heap')}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap flex items-center gap-1.5 ${
              activeSubTab === 'heap'
                ? 'bg-indigo-600 text-white shadow-xs'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <Database className="w-3.5 h-3.5" />
            <span>3. Python Priority Queue (heapq) State</span>
          </button>

          <button
            onClick={() => setActiveSubTab('complexity')}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap flex items-center gap-1.5 ${
              activeSubTab === 'complexity'
                ? 'bg-indigo-600 text-white shadow-xs'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <Cpu className="w-3.5 h-3.5" />
            <span>4. Python Module Architecture & Complexity</span>
          </button>
        </div>
      </div>

      {/* SUBTAB 1: PIPELINE ARCHITECTURE */}
      {activeSubTab === 'pipeline' && (
        <div className="space-y-6">
          {/* Real DAA Flowchart Card */}
          <div className="bg-white border border-slate-200 rounded-lg p-5 shadow-xs space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                <GitBranch className="w-4 h-4 text-blue-600" />
                <span>Python Backend Scheduling Execution Pipeline</span>
              </h2>
              <span className="text-[11px] font-mono text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                POST /api/schedule → Python 3.10
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-5 gap-3 relative">
              {/* Step 1 */}
              <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-lg">
                <div className="text-[10px] font-bold text-blue-700 uppercase">Stage 1: API Request</div>
                <h3 className="text-xs font-bold text-slate-900 mt-1">JSON Payload Ingestion</h3>
                <p className="text-[11px] text-slate-500 mt-1">
                  React sends registered patient requests & doctor availability via HTTP POST.
                </p>
                <div className="mt-2 text-[10px] font-mono text-slate-600 bg-white p-1 rounded border">
                  Input: N Patients (JSON)
                </div>
              </div>

              {/* Step 2 */}
              <div className="p-3.5 bg-blue-50/50 border border-blue-200 rounded-lg">
                <div className="text-[10px] font-bold text-blue-700 uppercase">Stage 2: Python Sorting</div>
                <h3 className="text-xs font-bold text-slate-900 mt-1">sort_patients()</h3>
                <p className="text-[11px] text-slate-600 mt-1">
                  backend/scheduler/sorting.py sorts Emergency (1) → Critical (2) → High (3) → Normal (4) → Routine (5).
                </p>
                <div className="mt-2 text-[10px] font-mono text-blue-800 bg-white p-1 rounded border border-blue-100">
                  O(N log N) in Python
                </div>
              </div>

              {/* Step 3 */}
              <div className="p-3.5 bg-indigo-50/50 border border-indigo-200 rounded-lg">
                <div className="text-[10px] font-bold text-indigo-700 uppercase">Stage 3: heapq Priority Queue</div>
                <h3 className="text-xs font-bold text-slate-900 mt-1">PriorityQueue.insert()</h3>
                <p className="text-[11px] text-slate-600 mt-1">
                  backend/scheduler/priority_queue.py builds binary min-heap with heapq.
                </p>
                <div className="mt-2 text-[10px] font-mono text-indigo-800 bg-white p-1 rounded border border-indigo-100">
                  extract_highest_priority()
                </div>
              </div>

              {/* Step 4 */}
              <div className="p-3.5 bg-teal-50/50 border border-teal-200 rounded-lg">
                <div className="text-[10px] font-bold text-teal-700 uppercase">Stage 4: Python Greedy</div>
                <h3 className="text-xs font-bold text-slate-900 mt-1">greedy_assign_appointment()</h3>
                <p className="text-[11px] text-slate-600 mt-1">
                  backend/scheduler/greedy_scheduler.py finds earliest feasible compatible slot.
                </p>
                <div className="mt-2 text-[10px] font-mono text-teal-800 bg-white p-1 rounded border border-teal-100">
                  Earliest feasible slot rule
                </div>
              </div>

              {/* Step 5 */}
              <div className="p-3.5 bg-emerald-50/50 border border-emerald-200 rounded-lg">
                <div className="text-[10px] font-bold text-emerald-700 uppercase">Stage 5: API Response</div>
                <h3 className="text-xs font-bold text-slate-900 mt-1">JSON Result Return</h3>
                <p className="text-[11px] text-slate-600 mt-1">
                  Python returns confirmed appointments, waiting list, and full execution trace to React.
                </p>
                <div className="mt-2 text-[10px] font-mono text-emerald-800 bg-white p-1 rounded border border-emerald-100">
                  HTTP 200 JSON Response
                </div>
              </div>
            </div>
          </div>

          {/* Sorting Summary from Real Python Execution */}
          {sortingTrace && (
            <div className="bg-white border border-slate-200 rounded-lg p-5 shadow-xs space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-bold text-slate-900">
                  Python Sorting Engine Execution Summary (backend/scheduler/sorting.py)
                </h3>
                <span className="text-xs font-mono text-blue-700 bg-blue-50 px-2 py-0.5 rounded">
                  {sortingTrace.total_sorted} Patient Requests Processed
                </span>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 text-xs">
                {Object.entries(sortingTrace.tier_counts || {}).map(([tier, count]) => (
                  <div key={tier} className="p-2.5 bg-slate-50 border border-slate-200 rounded text-center">
                    <span className="text-[11px] text-slate-500 block">{tier}</span>
                    <span className="text-lg font-bold text-slate-900 tabular-nums">{count as number}</span>
                  </div>
                ))}
              </div>

              <div className="mt-2 text-[11px] text-slate-600 space-y-1">
                <p><strong>Primary Sorting Criterion:</strong> {sortingTrace.primary_criterion}</p>
                <p><strong>Secondary Criterion:</strong> {sortingTrace.secondary_criterion}</p>
                <p><strong>Tertiary Criterion:</strong> {sortingTrace.tertiary_criterion}</p>
              </div>
            </div>
          )}

          {/* Python Backend Modules Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-white border border-slate-200 rounded-lg p-4 shadow-xs space-y-2">
              <span className="text-xs font-mono font-bold text-blue-700">backend/scheduler/sorting.py</span>
              <h4 className="text-sm font-bold text-slate-900">Deterministic Triage Sorter</h4>
              <p className="text-xs text-slate-600">
                Implements <code className="font-mono text-blue-700">sort_patients(patients)</code> in Python. Enforces priority hierarchy (Emergency = 1, Critical = 2, High = 3, Normal = 4, Routine = 5) followed by requested slot time.
              </p>
            </div>

            <div className="bg-white border border-slate-200 rounded-lg p-4 shadow-xs space-y-2">
              <span className="text-xs font-mono font-bold text-indigo-700">backend/scheduler/priority_queue.py</span>
              <h4 className="text-sm font-bold text-slate-900">Python heapq Min-Heap</h4>
              <p className="text-xs text-slate-600">
                Implements <code className="font-mono text-indigo-700">class PriorityQueue</code> using Python's standard <code className="font-mono text-indigo-700">heapq</code>. Provides <code className="font-mono text-indigo-700">insert()</code>, <code className="font-mono text-indigo-700">peek()</code>, and <code className="font-mono text-indigo-700">extract_highest_priority()</code> in $O(\log N)$.
              </p>
            </div>

            <div className="bg-white border border-slate-200 rounded-lg p-4 shadow-xs space-y-2">
              <span className="text-xs font-mono font-bold text-teal-700">backend/scheduler/greedy_scheduler.py</span>
              <h4 className="text-sm font-bold text-slate-900">Greedy Appointment Selector</h4>
              <p className="text-xs text-slate-600">
                Implements <code className="font-mono text-teal-700">greedy_assign_appointment()</code> in Python. Selects the earliest suitable available slot with a compatible doctor and applies deterministic tie-breakers.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* SUBTAB 2: STEP-BY-STEP EXECUTION TRACE */}
      {activeSubTab === 'trace' && (
        <div className="space-y-4">
          <div className="bg-white border border-slate-200 rounded-lg p-4 shadow-xs">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-sm font-bold text-slate-900">
                  Python Execution Trace Replay ({greedySteps.length} Steps Recorded)
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  Real step-by-step decisions streamed from the Python backend API.
                </p>
              </div>
              <span className="text-xs font-mono text-slate-500 bg-slate-100 px-2 py-1 rounded">
                API Response: execution.greedy_steps
              </span>
            </div>

            {/* Horizontal step selector */}
            <div className="mt-4 flex items-center gap-1.5 overflow-x-auto pb-2 scrollbar-thin">
              {greedySteps.map((step: any, idx: number) => {
                const isEmergency = step.urgency === 'Emergency' || step.urgency === 'Critical';
                const isSelected = selectedTraceStepIndex === idx;

                return (
                  <button
                    key={step.step_number || idx}
                    onClick={() => setSelectedTraceStepIndex(idx)}
                    className={`px-3 py-2 text-xs font-medium rounded border whitespace-nowrap transition-colors flex-shrink-0 text-left ${
                      isSelected
                        ? 'bg-indigo-600 text-white border-indigo-700 shadow-xs'
                        : isEmergency
                        ? 'bg-rose-50 text-rose-900 border-rose-200 hover:bg-rose-100'
                        : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                    }`}
                  >
                    <div className="font-bold flex items-center gap-1">
                      <span>Step #{step.step_number || idx + 1}</span>
                      {isEmergency && <span>🔴</span>}
                    </div>
                    <div className="text-[10px] opacity-80 truncate max-w-[120px]">
                      {step.patient_name} ({step.urgency})
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Current Step Detail */}
          {currentStep ? (
            <div className="bg-white border border-slate-200 rounded-lg p-5 shadow-xs space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-3 border-b border-slate-200 gap-2">
                <div>
                  <span className="text-xs font-bold text-indigo-700 uppercase">
                    Python Execution Step {currentStep.step_number} of {greedySteps.length}
                  </span>
                  <h3 className="text-base font-bold text-slate-900 mt-0.5">
                    Patient: {currentStep.patient_name}
                  </h3>
                  <div className="text-xs text-slate-500 mt-0.5">
                    Urgency: <strong className="text-slate-900">{currentStep.urgency}</strong> (Rank {currentStep.urgency_rank}) · Heap Extraction Order: #{currentStep.queue_extraction_order}
                  </div>
                </div>

                <div className="text-right">
                  <span className="inline-block px-3 py-1 bg-emerald-50 text-emerald-800 border border-emerald-200 rounded text-xs font-bold">
                    Assigned: {currentStep.chosen_doctor_name || 'No slot free'} at {currentStep.chosen_slot || 'N/A'}
                  </span>
                </div>
              </div>

              {/* 5-Step Evaluation Details */}
              <div className="space-y-3 text-xs">
                <div className="p-3 bg-slate-50 border border-slate-200 rounded">
                  <span className="font-bold text-slate-900 block">
                    STEP 1 — Python Sorting Execution
                  </span>
                  <p className="text-slate-600 mt-0.5">
                    Patient assigned urgency rank <span className="font-semibold">{currentStep.urgency_rank}</span> ({currentStep.urgency}) in <code className="font-mono text-blue-700">sorting.py</code>.
                  </p>
                </div>

                <div className="p-3 bg-slate-50 border border-slate-200 rounded">
                  <span className="font-bold text-slate-900 block">
                    STEP 2 — Priority Queue Extraction (heapq)
                  </span>
                  <p className="text-slate-600 mt-0.5">
                    Extracted from Python min-heap root at extraction index #{currentStep.queue_extraction_order}.
                  </p>
                </div>

                <div className="p-3 bg-slate-50 border border-slate-200 rounded">
                  <span className="font-bold text-slate-900 block">
                    STEP 3 — Compatible Doctors Evaluated ({currentStep.candidate_doctors?.length || 0} Candidates)
                  </span>
                  <div className="mt-2 grid grid-cols-1 sm:grid-cols-3 gap-2">
                    {(currentStep.candidate_doctors || []).map((doc: any) => (
                      <div
                        key={doc.id}
                        className={`p-2 rounded border text-[11px] ${
                          doc.id === currentStep.chosen_doctor_id
                            ? 'bg-blue-50 border-blue-300 font-semibold text-blue-900'
                            : 'bg-white border-slate-200 text-slate-700'
                        }`}
                      >
                        <div>{doc.name}</div>
                        <div className="text-slate-500 text-[10px]">
                          Workload: {doc.current_workload}/{doc.max_capacity} slots
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="p-3 bg-slate-50 border border-slate-200 rounded">
                  <span className="font-bold text-slate-900 block">
                    STEP 4 — Available Slots Evaluated Chronologically
                  </span>
                  <div className="mt-2 flex flex-wrap gap-1.5">
                    {(currentStep.evaluated_slots || []).map((ev: any, i: number) => (
                      <span
                        key={i}
                        className={`px-2 py-1 rounded text-[10px] font-mono border ${
                          ev.is_free
                            ? 'bg-emerald-50 text-emerald-800 border-emerald-200 font-bold'
                            : 'bg-slate-100 text-slate-500 border-slate-200 line-through'
                        }`}
                        title={`${ev.doctor_name} @ ${ev.slot}: ${ev.notes || ''}`}
                      >
                        {ev.slot} ({ev.doctor_name?.split(' ').pop()}): {ev.is_free ? 'FREE' : 'UNAVAIL'}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="p-3 bg-indigo-50/60 border border-indigo-200 rounded text-indigo-950">
                  <span className="font-bold block">
                    STEP 5 — Greedy Selection Decision in Python
                  </span>
                  <p className="mt-0.5">
                    <strong>Greedy Choice:</strong> {currentStep.greedy_criterion_met}
                  </p>
                  {currentStep.tie_breaker_used && (
                    <p className="mt-1 text-indigo-800 font-medium">
                      <strong>Tie-Breaker:</strong> {currentStep.tie_breaker_used}
                    </p>
                  )}
                </div>
              </div>
            </div>
          ) : (
            <div className="p-8 text-center text-slate-400 bg-white border border-slate-200 rounded-lg">
              No trace recorded yet. Run Automatic Scheduling to generate the step-by-step replay!
            </div>
          )}
        </div>
      )}

      {/* SUBTAB 3: PRIORITY QUEUE (heapq) STATE */}
      {activeSubTab === 'heap' && (
        <div className="space-y-4">
          <div className="bg-white border border-slate-200 rounded-lg p-5 shadow-xs space-y-3">
            <div className="flex items-center justify-between">
              <h2 className="text-sm font-bold text-slate-900">
                Python Priority Queue (heapq) Extraction Sequence
              </h2>
              <span className="text-xs font-mono text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded">
                backend/scheduler/priority_queue.py
              </span>
            </div>
            <p className="text-xs text-slate-500">
              Below is the extraction sequence recorded by the Python <code className="font-mono">PriorityQueue</code> instance. Emergency patients (rank 1) are extracted first.
            </p>

            <div className="mt-3 overflow-x-auto">
              <table className="w-full text-left text-xs border border-slate-200 rounded">
                <thead>
                  <tr className="bg-slate-50 border-b border-slate-200 text-slate-700 font-semibold">
                    <th className="py-2 px-3">Extraction Order</th>
                    <th className="py-2 px-3">Priority Rank</th>
                    <th className="py-2 px-3">Patient</th>
                    <th className="py-2 px-3">Patient ID</th>
                    <th className="py-2 px-3">Urgency Tier</th>
                    <th className="py-2 px-3">Queue Size Remaining</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 font-mono text-[11px]">
                  {pqExtractions.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="py-6 text-center text-slate-400 font-sans">
                        No extraction sequence recorded yet. Click "Re-Run Python Scheduler" above.
                      </td>
                    </tr>
                  ) : (
                    pqExtractions.map((node: any, i: number) => {
                      const isRoot = i === 0;

                      return (
                        <tr
                          key={i}
                          className={`${
                            isRoot
                              ? 'bg-blue-50/70 font-semibold text-blue-950'
                              : node.priority_rank === 1
                              ? 'bg-rose-50/40 text-rose-950'
                              : 'hover:bg-slate-50'
                          }`}
                        >
                          <td className="py-2 px-3">
                            <span className="font-bold text-slate-900">#{node.extraction_order || i + 1}</span>
                            {isRoot && <span className="ml-1 text-[10px] text-blue-700">(Root / Triage First)</span>}
                          </td>
                          <td className="py-2 px-3 font-bold text-indigo-700">{node.priority_rank}</td>
                          <td className="py-2 px-3 font-sans font-medium text-slate-900">
                            {node.patient_name}
                          </td>
                          <td className="py-2 px-3 text-slate-500">{node.patient_id}</td>
                          <td className="py-2 px-3 font-sans">
                            {node.priority_rank === 1 ? (
                              <span className="text-rose-700 font-bold">🔴 Emergency</span>
                            ) : (
                              node.urgency
                            )}
                          </td>
                          <td className="py-2 px-3 text-slate-500 tabular-nums">{node.queue_size_remaining}</td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* SUBTAB 4: COMPLEXITY & PYTHON ARCHITECTURE */}
      {activeSubTab === 'complexity' && (
        <div className="space-y-4">
          <div className="bg-white border border-slate-200 rounded-lg p-5 shadow-xs space-y-4">
            <h2 className="text-sm font-bold text-slate-900">
              Python Backend Architecture & Asymptotic Complexity
            </h2>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
              <div className="p-4 bg-slate-50 border border-slate-200 rounded-lg space-y-2">
                <h3 className="font-bold text-slate-900">Python Backend Time Complexity</h3>
                <ul className="space-y-1 text-slate-700">
                  <li>
                    <strong>1. sorting.py:</strong> <code className="font-mono text-blue-700">O(N log N)</code> using Python Timsort.
                  </li>
                  <li>
                    <strong>2. priority_queue.py:</strong> <code className="font-mono text-indigo-700">O(log N)</code> per <code className="font-mono">heapq.heappush</code> and <code className="font-mono">heapq.heappop</code>.
                  </li>
                  <li>
                    <strong>3. greedy_scheduler.py:</strong> <code className="font-mono text-teal-700">O(D · S)</code> per patient (checks <code className="font-mono text-teal-700">D</code> doctors and <code className="font-mono text-teal-700">S</code> slots).
                  </li>
                  <li>
                    <strong>Overall Python Pipeline:</strong> <code className="font-mono text-slate-900 font-bold">O(N log N + N · D · S)</code>.
                  </li>
                </ul>
              </div>

              <div className="p-4 bg-slate-50 border border-slate-200 rounded-lg space-y-2">
                <h3 className="font-bold text-slate-900">Python File Layout</h3>
                <ul className="space-y-1 font-mono text-[11px] text-slate-700">
                  <li><strong className="text-blue-700">backend/main.py:</strong> HTTP API router</li>
                  <li><strong className="text-blue-700">backend/scheduler/sorting.py:</strong> sort_patients()</li>
                  <li><strong className="text-blue-700">backend/scheduler/priority_queue.py:</strong> PriorityQueue</li>
                  <li><strong className="text-blue-700">backend/scheduler/greedy_scheduler.py:</strong> greedy selection</li>
                  <li><strong className="text-blue-700">backend/scheduler/scheduler.py:</strong> pipeline coordinator</li>
                  <li><strong className="text-blue-700">backend/scheduler/models.py:</strong> typing and constants</li>
                </ul>
              </div>
            </div>

            <div className="p-4 bg-blue-50/60 border border-blue-200 rounded-lg text-xs text-blue-950 space-y-2">
              <h3 className="font-bold">Architectural Verification</h3>
              <p className="leading-relaxed">
                The user interface in React communicates with Python via HTTP API requests (<code className="font-mono text-blue-800">POST /api/schedule</code>, <code className="font-mono text-blue-800">POST /api/appointments</code>, <code className="font-mono text-blue-800">POST /api/cancel</code>, <code className="font-mono text-blue-800">POST /api/doctor-unavailable</code>).
              </p>
              <p className="leading-relaxed">
                No scheduling algorithms are duplicated in TypeScript. The frontend acts exclusively as the presentation layer, while Python performs patient sorting, priority queue heap operations, greedy slot allocations, and dynamic rescheduling.
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
