import React from 'react';
import {
  Activity,
  Calendar,
  Users,
  UserCheck,
  Clock,
  Code2,
  PlusCircle,
  Play,
  AlertTriangle,
} from 'lucide-react';

interface HeaderProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  emergencyCount: number;
  pendingRequestsCount: number;
  onOpenBooking: () => void;
  onRunAutomaticScheduling: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  emergencyCount,
  pendingRequestsCount,
  onOpenBooking,
  onRunAutomaticScheduling,
}) => {
  const navItems = [
    { id: 'dashboard', label: 'Dashboard', icon: Activity },
    { id: 'schedule', label: 'Live Schedule', icon: Calendar },
    { id: 'doctors', label: 'Doctors & Availability', icon: UserCheck },
    { id: 'patients', label: 'Patients', icon: Users },
    { id: 'waiting', label: 'Waiting List', icon: Clock },
    { id: 'algorithms', label: 'Technical / Algorithm Details', icon: Code2 },
  ];

  return (
    <header className="sticky top-0 z-40 bg-slate-900 border-b border-slate-800 text-white shadow-md">
      {/* Top Main Navigation Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Zone 1: Single text element wordmark with clinical cross motif */}
          <div className="flex items-center gap-3">
            <div className="h-9 w-9 rounded-lg bg-blue-600 flex items-center justify-center font-bold text-white text-lg shadow-sm">
              <span className="text-xl leading-none">✚</span>
            </div>
            <div>
              <span className="text-xl font-bold tracking-tight text-white">
                PulseCare
              </span>
              <span className="hidden sm:inline-block ml-2 text-xs text-slate-400 font-normal">
                Hospital Clinical Scheduler
              </span>
            </div>
          </div>

          {/* Zone 2: Navigation Links */}
          <nav className="hidden lg:flex items-center gap-1">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              const isTechTab = item.id === 'algorithms';
              return (
                <button
                  key={item.id}
                  onClick={() => setActiveTab(item.id)}
                  className={`flex items-center gap-2 px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                    isActive
                      ? isTechTab
                        ? 'bg-indigo-600 text-white shadow-sm'
                        : 'bg-blue-600 text-white shadow-sm'
                      : isTechTab
                      ? 'text-indigo-300 hover:text-white hover:bg-indigo-950/60'
                      : 'text-slate-300 hover:text-white hover:bg-slate-800'
                  }`}
                >
                  <Icon className="w-3.5 h-3.5" />
                  <span>{item.label}</span>
                  {item.id === 'waiting' && pendingRequestsCount > 0 && (
                    <span className="ml-1 px-1.5 py-0.2 text-[10px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30 rounded">
                      {pendingRequestsCount}
                    </span>
                  )}
                </button>
              );
            })}
          </nav>

          {/* Zone 3: Primary Actions */}
          <div className="flex items-center gap-2 sm:gap-3">
            {emergencyCount > 0 && (
              <button
                onClick={() => setActiveTab('schedule')}
                className="flex items-center gap-1.5 px-2.5 py-1 text-xs font-semibold bg-rose-950/80 text-rose-300 border border-rose-700/60 rounded-md animate-pulse hover:bg-rose-900 transition-colors"
                title={`${emergencyCount} active emergency case(s) requiring immediate attention`}
              >
                <span className="w-2 h-2 rounded-full bg-rose-500 inline-block animate-ping"></span>
                <span>🔴 {emergencyCount} Emergency</span>
              </button>
            )}

            <button
              onClick={onRunAutomaticScheduling}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-200 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-md transition-colors whitespace-nowrap"
              title="Automatically triage pending requests and assign earliest feasible doctor slots"
            >
              <Play className="w-3.5 h-3.5 text-blue-400" />
              <span className="hidden sm:inline">Run Automatic</span>
              <span>Scheduling</span>
            </button>

            <button
              onClick={onOpenBooking}
              className="flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-500 rounded-md transition-colors shadow-sm whitespace-nowrap"
            >
              <PlusCircle className="w-4 h-4" />
              <span>Book Appointment</span>
            </button>
          </div>
        </div>

        {/* Mobile / Tablet Horizontal Navigation Scroll */}
        <div className="flex lg:hidden overflow-x-auto py-2 border-t border-slate-800 gap-1 scrollbar-none">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`flex items-center gap-1.5 px-2.5 py-1 text-xs font-medium rounded-md whitespace-nowrap ${
                  isActive
                    ? 'bg-blue-600 text-white'
                    : 'text-slate-300 hover:bg-slate-800'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{item.label}</span>
              </button>
            );
          })}
        </div>
      </div>
    </header>
  );
};
