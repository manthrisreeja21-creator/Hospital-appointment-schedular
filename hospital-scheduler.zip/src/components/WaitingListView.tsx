import React from 'react';
import { Clock, AlertCircle, Play, UserPlus, ArrowRight } from 'lucide-react';
import { PatientRequest } from '../types';

interface WaitingListViewProps {
  waitingList: PatientRequest[];
  pendingRequests: PatientRequest[];
  onRunAutomaticScheduling: () => void;
  onOpenBooking: () => void;
}

export const WaitingListView: React.FC<WaitingListViewProps> = ({
  waitingList,
  pendingRequests,
  onRunAutomaticScheduling,
  onOpenBooking,
}) => {
  const allQueuedPatients = [...pendingRequests, ...waitingList];

  // Sort by urgency for visual priority
  const urgencyWeight: Record<string, number> = {
    Emergency: 1,
    Critical: 2,
    High: 3,
    Normal: 4,
    Low: 5,
  };

  const sortedQueued = [...allQueuedPatients].sort((a, b) => {
    const wa = urgencyWeight[a.urgency] ?? 5;
    const wb = urgencyWeight[b.urgency] ?? 5;
    if (wa !== wb) return wa - wb;
    return a.requestTimestamp - b.requestTimestamp;
  });

  const emergencyCount = sortedQueued.filter(
    (p) => p.urgency === 'Emergency' || p.urgency === 'Critical'
  ).length;

  return (
    <div className="space-y-5">
      {/* Header card */}
      <div className="bg-white border border-slate-200 rounded-lg p-4 sm:p-5 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h1 className="text-lg font-bold text-slate-900 tracking-tight flex items-center gap-2">
              <Clock className="w-5 h-5 text-amber-600" />
              <span>Priority Triage Waiting Queue</span>
            </h1>
            <p className="text-xs text-slate-500 mt-1">
              Patients currently in queue organized deterministically by clinical urgency and request time.
              When appointments are cancelled or new slots open, highest priority patients are immediately allocated.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onRunAutomaticScheduling}
              disabled={sortedQueued.length === 0}
              className="px-4 py-2 text-xs font-semibold bg-blue-600 hover:bg-blue-700 disabled:bg-slate-300 disabled:cursor-not-allowed text-white rounded-md transition-colors shadow-xs flex items-center gap-1.5"
            >
              <Play className="w-3.5 h-3.5" />
              <span>Assign Feasible Doctor Slots</span>
            </button>
            <button
              onClick={onOpenBooking}
              className="px-3 py-2 text-xs font-semibold bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-md transition-colors border border-slate-200"
            >
              + Register Patient
            </button>
          </div>
        </div>

        {emergencyCount > 0 && (
          <div className="mt-4 p-3 bg-rose-50 border border-rose-200 rounded-md flex items-center justify-between text-xs text-rose-950">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-rose-600 animate-pulse"></span>
              <span className="font-bold">
                🔴 {emergencyCount} Emergency/Critical Patient(s) In Queue
              </span>
              <span className="text-rose-700 hidden sm:inline">
                — Placed at the head of the Priority Queue for the next available specialist consultation.
              </span>
            </div>
            <button
              onClick={onRunAutomaticScheduling}
              className="font-bold text-rose-700 hover:underline flex items-center gap-1"
            >
              <span>Process Now</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        )}
      </div>

      {/* Waiting Table */}
      <div className="bg-white border border-slate-200 rounded-lg shadow-xs overflow-hidden">
        {sortedQueued.length === 0 ? (
          <div className="p-12 text-center text-slate-400">
            <p className="text-sm font-medium">The waiting queue is currently clear.</p>
            <p className="text-xs text-slate-400 mt-1">
              All registered patients have been successfully scheduled into doctor consultation slots.
            </p>
            <button
              onClick={onOpenBooking}
              className="mt-4 px-3 py-1.5 text-xs font-semibold bg-blue-600 text-white rounded-md"
            >
              Register New Patient
            </button>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-slate-50/80 border-b border-slate-200 text-slate-600 font-semibold">
                  <th className="py-3 px-4">Queue Rank</th>
                  <th className="py-3 px-4">Patient</th>
                  <th className="py-3 px-4">Department</th>
                  <th className="py-3 px-4">Urgency Level</th>
                  <th className="py-3 px-4">Symptoms / Triage Note</th>
                  <th className="py-3 px-4">Preferred Slot</th>
                  <th className="py-3 px-4">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {sortedQueued.map((p, index) => {
                  const isEmergency = p.urgency === 'Emergency' || p.urgency === 'Critical';

                  return (
                    <tr
                      key={p.id}
                      className={`transition-colors ${
                        isEmergency ? 'bg-rose-50/40 hover:bg-rose-50/70' : 'hover:bg-slate-50'
                      }`}
                    >
                      {/* Priority Queue Rank */}
                      <td className="py-3 px-4 whitespace-nowrap">
                        <span
                          className={`inline-flex items-center justify-center w-6 h-6 rounded-full font-bold text-xs tabular-nums ${
                            index === 0
                              ? 'bg-blue-600 text-white'
                              : isEmergency
                              ? 'bg-rose-600 text-white'
                              : 'bg-slate-100 text-slate-700'
                          }`}
                        >
                          {index + 1}
                        </span>
                      </td>

                      {/* Patient Name */}
                      <td className="py-3 px-4">
                        <div>
                          <span className="font-semibold text-slate-900 block text-sm">
                            {p.patientName}
                          </span>
                          <span className="text-slate-500 text-[11px]">
                            {p.age} yrs · {p.contact} · ID: {p.id}
                          </span>
                        </div>
                      </td>

                      {/* Department */}
                      <td className="py-3 px-4 font-medium text-slate-800">{p.department}</td>

                      {/* Urgency */}
                      <td className="py-3 px-4 whitespace-nowrap">
                        {p.urgency === 'Emergency' ? (
                          <span className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-bold text-rose-800 bg-rose-100 border border-rose-300 rounded shadow-xs">
                            <span>🔴 EMERGENCY</span>
                          </span>
                        ) : p.urgency === 'Critical' ? (
                          <span className="inline-flex items-center px-2 py-0.5 text-xs font-semibold text-rose-700 bg-rose-50 border border-rose-200 rounded">
                            Critical
                          </span>
                        ) : p.urgency === 'High' ? (
                          <span className="inline-flex items-center px-2 py-0.5 text-xs font-semibold text-amber-800 bg-amber-50 border border-amber-200 rounded">
                            High
                          </span>
                        ) : p.urgency === 'Normal' ? (
                          <span className="inline-flex items-center px-2 py-0.5 text-xs text-slate-700 bg-slate-100 rounded">
                            Normal
                          </span>
                        ) : (
                          <span className="inline-flex items-center px-2 py-0.5 text-xs text-slate-500 bg-slate-100 rounded">
                            Routine
                          </span>
                        )}
                      </td>

                      {/* Symptoms */}
                      <td className="py-3 px-4 text-slate-600 max-w-xs truncate" title={p.symptoms}>
                        {p.symptoms || p.reasonForPriority || 'Standard consultation requested'}
                      </td>

                      {/* Preferred Slot */}
                      <td className="py-3 px-4 text-slate-600 whitespace-nowrap">
                        {p.preferredTimeSlot || 'Any available slot'}
                      </td>

                      {/* Status */}
                      <td className="py-3 px-4 whitespace-nowrap">
                        <span className="px-2 py-0.5 bg-amber-50 text-amber-700 border border-amber-200 rounded text-[11px] font-medium">
                          In Priority Queue
                        </span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
