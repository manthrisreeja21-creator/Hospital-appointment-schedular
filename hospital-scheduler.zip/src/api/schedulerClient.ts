/**
 * Client for communicating with the Python DAA Scheduling Backend.
 * All algorithm executions (Sorting, Priority Queue, Greedy Selection, Rescheduling)
 * occur in the Python backend.
 */

import { Doctor, PatientRequest, Appointment, SchedulingRunResult, RescheduleIncident } from '../types';

export interface PythonScheduleResponse {
  appointments: Appointment[];
  updated_appointments: Appointment[];
  waiting_list: PatientRequest[];
  execution: {
    sorting: {
      total_sorted: number;
      tier_counts: Record<string, number>;
      sorted_patient_ids: string[];
      sorted_patient_summary: {
        id: string;
        name: string;
        urgency: string;
        rank: number;
        department: string;
      }[];
      primary_criterion: string;
      secondary_criterion: string;
      tertiary_criterion: string;
    };
    priority_queue_insertions: any[];
    priority_queue_extractions: any[];
    priority_queue_steps: any[];
    greedy_steps: any[];
    doctors_utilized: number;
    emergencies_handled: number;
    scheduled_count: number;
    waiting_count: number;
    target_date: string;
    timestamp: number;
  };
}

export interface PythonAppointmentResponse {
  success: boolean;
  appointment?: Appointment;
  reason?: string;
  trace_step?: any;
}

export interface PythonCancellationResponse {
  updated_appointments: Appointment[];
  updated_waiting_list: PatientRequest[];
  promoted_appointment?: Appointment | null;
}

export interface PythonDoctorUnavailableResponse {
  updated_doctors: Doctor[];
  updated_appointments: Appointment[];
  new_waiting_requests: PatientRequest[];
  incident: RescheduleIncident;
  execution?: any;
}

/**
 * 1. Executes DAA Scheduling Pipeline in Python:
 * Sorting -> Priority Queue -> Greedy Doctor/Slot Assignment
 */
export async function runPythonSchedule(
  patients: PatientRequest[],
  doctors: Doctor[],
  existingAppointments: Appointment[],
  targetDate: string = '2026-10-03'
): Promise<PythonScheduleResponse> {
  const response = await fetch('/api/schedule', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      patients,
      doctors,
      existing_appointments: existingAppointments,
      target_date: targetDate,
    }),
  });

  if (!response.ok) {
    throw new Error(`Python scheduling failed with HTTP status ${response.status}`);
  }
  return await response.json();
}

/**
 * 2. Books a single patient by sending it to Python for Greedy Appointment Allocation
 */
export async function bookPatientInPython(
  patient: PatientRequest,
  doctors: Doctor[],
  existingAppointments: Appointment[],
  targetDate: string = '2026-10-03'
): Promise<PythonAppointmentResponse> {
  const response = await fetch('/api/appointments', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      patient,
      doctors,
      existing_appointments: existingAppointments,
      target_date: targetDate,
    }),
  });

  if (!response.ok) {
    throw new Error(`Python appointment booking failed with status ${response.status}`);
  }
  return await response.json();
}

/**
 * 3. Handles Cancellation in Python:
 * Releases slot, extracts highest-priority waiting patient via heapq Priority Queue
 */
export async function cancelAppointmentInPython(
  appointmentId: string,
  appointments: Appointment[],
  doctors: Doctor[],
  waitingList: PatientRequest[]
): Promise<PythonCancellationResponse> {
  const response = await fetch('/api/cancel', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      appointment_id: appointmentId,
      appointments,
      doctors,
      waiting_list: waitingList,
    }),
  });

  if (!response.ok) {
    throw new Error(`Python cancellation failed with status ${response.status}`);
  }
  return await response.json();
}

/**
 * 4. Handles Doctor Unavailability in Python:
 * Reschedules affected patients to compatible specialists using Priority Queue
 */
export async function doctorUnavailableInPython(
  doctorId: string,
  doctors: Doctor[],
  appointments: Appointment[],
  waitingList: PatientRequest[],
  targetDate: string = '2026-10-03'
): Promise<PythonDoctorUnavailableResponse> {
  const response = await fetch('/api/doctor-unavailable', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      doctor_id: doctorId,
      doctors,
      appointments,
      waiting_list: waitingList,
      target_date: targetDate,
    }),
  });

  if (!response.ok) {
    throw new Error(`Python dynamic rescheduling failed with status ${response.status}`);
  }
  return await response.json();
}

/**
 * 5. Handles No-Show in Python
 */
export async function markNoShowInPython(
  appointmentId: string,
  appointments: Appointment[],
  doctors: Doctor[],
  waitingList: PatientRequest[]
): Promise<{ updated_appointments: Appointment[]; updated_waiting_list: PatientRequest[] }> {
  const response = await fetch('/api/no-show', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      appointment_id: appointmentId,
      appointments,
      doctors,
      waiting_list: waitingList,
    }),
  });

  if (!response.ok) {
    throw new Error(`Python no-show update failed with status ${response.status}`);
  }
  return await response.json();
}
