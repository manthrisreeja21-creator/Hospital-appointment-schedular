export type Department =
  | 'Cardiology'
  | 'General Medicine'
  | 'Pediatrics'
  | 'Orthopedics'
  | 'Neurology'
  | 'Dermatology'
  | 'ENT'
  | 'Gynecology'
  | 'General Surgery'
  | 'Ophthalmology';

export type UrgencyLevel = 'Emergency' | 'Critical' | 'High' | 'Normal' | 'Low';

export type AppointmentStatus =
  | 'Confirmed'
  | 'In Consultation'
  | 'Completed'
  | 'Cancelled'
  | 'Rescheduled'
  | 'Waiting'
  | 'No Show';

export type DoctorStatus =
  | 'Available'
  | 'In Consultation'
  | 'On Break'
  | 'Fully Booked'
  | 'Unavailable';

export const ALL_STANDARD_SLOTS: string[] = [
  '09:00',
  '09:30',
  '10:00',
  '10:30',
  '11:00',
  '11:30',
  '12:00',
  '13:30',
  '14:00',
  '14:30',
  '15:00',
  '15:30',
  '16:00',
  '16:30',
];

export interface Doctor {
  id: string;
  name: string;
  department: Department;
  specialization: string;
  experienceYears: number;
  status: DoctorStatus;
  roomNumber: string;
  maxDailyCapacity: number;
  availableSlots: string[]; // e.g. ["09:00", "09:30", "10:00", ...]
  currentAppointmentCount: number;
  contact: string;
  qualification: string;
}

export interface PatientRequest {
  id: string;
  patientName: string;
  age: number;
  gender: 'Male' | 'Female' | 'Other';
  contact: string;
  department: Department;
  preferredDoctorId?: string;
  urgency: UrgencyLevel;
  preferredDate: string; // YYYY-MM-DD
  preferredTimeSlot?: string; // e.g. "Morning (09:00 - 12:00)", "Afternoon (13:00 - 16:30)", or specific slot
  symptoms: string;
  requestTimestamp: number;
  status: 'Pending' | 'Scheduled' | 'Waiting' | 'Cancelled' | 'No Show';
  reasonForPriority?: string;
}

export interface AppointmentExplanation {
  priorityReason: string;
  doctorReason: string;
  availabilityReason: string;
  preferenceMatch: string;
  decisionSummary: string;
}

export interface AlgorithmTraceStep {
  stepNumber: number;
  patientId: string;
  patientName: string;
  urgency: UrgencyLevel;
  urgencyRank: number; // 1 = Emergency, 2 = Critical, 3 = High, 4 = Normal, 5 = Low
  queueExtractionOrder: number;
  candidateDoctors: {
    id: string;
    name: string;
    isAvailable: boolean;
    currentWorkload: number;
    maxCapacity: number;
  }[];
  evaluatedSlots: {
    slot: string;
    doctorId: string;
    doctorName: string;
    isFree: boolean;
    notes?: string;
  }[];
  chosenDoctorId: string;
  chosenDoctorName: string;
  chosenSlot: string;
  greedyCriterionMet: string;
  tieBreakerUsed?: string;
  executionTimestamp: number;
}

export interface Appointment {
  id: string;
  patientId: string;
  patientName: string;
  patientAge: number;
  patientContact: string;
  patientUrgency: UrgencyLevel;
  doctorId: string;
  doctorName: string;
  department: Department;
  date: string;
  timeSlot: string;
  status: AppointmentStatus;
  bookedAt: number;
  selectionExplanation: AppointmentExplanation;
  algorithmTrace?: AlgorithmTraceStep;
  rescheduledFromDoctorId?: string;
  rescheduleReason?: string;
}

export interface SchedulingRunResult {
  runId: string;
  timestamp: number;
  scheduledAppointmentsCount: number;
  emergenciesHandled: number;
  waitingCount: number;
  doctorsUtilized: number;
  unassignedCount: number;
  traceSteps: AlgorithmTraceStep[];
  sortingSummary: {
    totalSorted: number;
    emergencyCount: number;
    criticalCount: number;
    highCount: number;
    normalCount: number;
    lowCount: number;
    primaryKey: string;
    secondaryKey: string;
  };
}

export interface RescheduleIncident {
  id: string;
  timestamp: number;
  unavailableDoctorId: string;
  unavailableDoctorName: string;
  department: Department;
  affectedAppointmentsCount: number;
  successfullyRescheduledCount: number;
  movedToWaitingCount: number;
  details: {
    patientName: string;
    urgency: UrgencyLevel;
    originalSlot: string;
    newDoctorName?: string;
    newSlot?: string;
    status: 'Rescheduled' | 'Moved to Waiting';
  }[];
}
