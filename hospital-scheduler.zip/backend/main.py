#!/usr/bin/env python3
"""
PulseCare Hospital Scheduler - Python Backend Server
Exposes HTTP JSON API endpoints for DAA scheduling logic.
"""

import json
import sys
import os
from http.server import HTTPServer, BaseHTTPRequestHandler
from socketserver import ThreadingMixIn
from urllib.parse import urlparse, parse_qs
from typing import Any, Dict

# Add backend directory to sys.path
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)

from backend.scheduler import (
    sort_patients,
    get_sorting_trace,
    PriorityQueue,
    greedy_assign_appointment,
    schedule_appointments,
    handle_cancellation,
    handle_no_show,
    handle_doctor_unavailable,
)

PORT = int(os.environ.get("PYTHON_PORT", 8000))


class ThreadedHTTPServer(ThreadingMixIn, HTTPServer):
    daemon_threads = True
    allow_reuse_address = True


class SchedulerAPIHandler(BaseHTTPRequestHandler):

    def _set_cors_headers(self, status_code: int = 200, content_type: str = "application/json"):
        self.send_response(status_code)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS, PUT, DELETE")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, Authorization, X-Requested-With")
        self.send_header("Content-Type", content_type)
        self.end_headers()

    def do_OPTIONS(self):
        self._set_cors_headers(204)

    def _read_json_body(self) -> Dict[str, Any]:
        content_length = int(self.headers.get("Content-Length", 0))
        if content_length <= 0:
            return {}
        raw_body = self.rfile.read(content_length).decode("utf-8")
        try:
            return json.loads(raw_body)
        except json.JSONDecodeError:
            return {}

    def _send_json(self, data: Any, status_code: int = 200):
        self._set_cors_headers(status_code)
        self.wfile.write(json.dumps(data).encode("utf-8"))

    def _send_error(self, message: str, status_code: int = 400):
        self._set_cors_headers(status_code)
        self.wfile.write(json.dumps({"error": message, "success": False}).encode("utf-8"))

    def do_GET(self):
        parsed = urlparse(self.path)
        path = parsed.path.rstrip("/")

        if path == "/api/health":
            self._send_json({
                "status": "healthy",
                "service": "PulseCare DAA Python Backend",
                "engine": "Python 3.10 Standard Library (heapq, sorting, greedy)",
            })
            return

        self._send_error(f"Endpoint GET {path} not found", 404)

    def do_POST(self):
        parsed = urlparse(self.path)
        path = parsed.path.rstrip("/")
        body = self._read_json_body()

        try:
            # 1. POST /api/schedule
            if path == "/api/schedule":
                patients = body.get("patients", [])
                doctors = body.get("doctors", [])
                existing_appointments = body.get("existing_appointments") or body.get("existingAppointments") or []
                target_date = body.get("target_date") or body.get("targetDate") or "2026-10-03"

                result = schedule_appointments(
                    patients=patients,
                    doctors=doctors,
                    existing_appointments=existing_appointments,
                    target_date=target_date,
                )
                self._send_json(result)
                return

            # 2. POST /api/appointments (single appointment greedy booking)
            elif path == "/api/appointments" or path == "/api/patients":
                patient = body.get("patient") or body
                doctors = body.get("doctors", [])
                existing_appointments = body.get("existing_appointments") or body.get("existingAppointments") or []
                target_date = body.get("target_date") or body.get("targetDate") or patient.get("preferredDate") or "2026-10-03"

                assignment = greedy_assign_appointment(
                    patient=patient,
                    doctors=doctors,
                    existing_appointments=existing_appointments,
                    target_date=target_date,
                    step_number=body.get("step_number", 1),
                    queue_extraction_order=body.get("queue_extraction_order", 1),
                )
                self._send_json(assignment)
                return

            # 3. POST /api/cancel
            elif path == "/api/cancel":
                appointment_id = body.get("appointment_id") or body.get("appointmentId")
                appointments = body.get("appointments", [])
                doctors = body.get("doctors", [])
                waiting_list = body.get("waiting_list") or body.get("waitingList") or []

                result = handle_cancellation(
                    appointment_id=appointment_id,
                    appointments=appointments,
                    doctors=doctors,
                    waiting_list=waiting_list,
                )
                self._send_json(result)
                return

            # 4. POST /api/doctor-unavailable
            elif path == "/api/doctor-unavailable":
                doctor_id = body.get("doctor_id") or body.get("doctorId")
                doctors = body.get("doctors", [])
                appointments = body.get("appointments", [])
                waiting_list = body.get("waiting_list") or body.get("waitingList") or []
                target_date = body.get("target_date") or body.get("targetDate") or "2026-10-03"

                result = handle_doctor_unavailable(
                    doctor_id=doctor_id,
                    doctors=doctors,
                    appointments=appointments,
                    waiting_list=waiting_list,
                    target_date=target_date,
                )
                self._send_json(result)
                return

            # 5. POST /api/no-show
            elif path == "/api/no-show":
                appointment_id = body.get("appointment_id") or body.get("appointmentId")
                appointments = body.get("appointments", [])
                doctors = body.get("doctors", [])
                waiting_list = body.get("waiting_list") or body.get("waitingList") or []

                result = handle_no_show(
                    appointment_id=appointment_id,
                    appointments=appointments,
                    doctors=doctors,
                    waiting_list=waiting_list,
                )
                self._send_json(result)
                return

            # 6. POST /api/reschedule
            elif path == "/api/reschedule":
                # General rescheduling endpoint
                patients = body.get("patients", [])
                doctors = body.get("doctors", [])
                existing_appointments = body.get("existing_appointments") or []
                target_date = body.get("target_date", "2026-10-03")

                result = schedule_appointments(
                    patients=patients,
                    doctors=doctors,
                    existing_appointments=existing_appointments,
                    target_date=target_date,
                )
                self._send_json(result)
                return

            self._send_error(f"Endpoint POST {path} not found", 404)

        except Exception as e:
            self._send_error(f"Internal server error: {str(e)}", 500)


def run_cli_dispatch(payload_json: str):
    """Direct execution mode for CLI integration."""
    try:
        data = json.loads(payload_json)
        action = data.get("action", "schedule")
        if action == "schedule":
            res = schedule_appointments(
                patients=data.get("patients", []),
                doctors=data.get("doctors", []),
                existing_appointments=data.get("existing_appointments", []),
                target_date=data.get("target_date", "2026-10-03"),
            )
            print(json.dumps(res))
        elif action == "appointment":
            res = greedy_assign_appointment(
                patient=data.get("patient", {}),
                doctors=data.get("doctors", []),
                existing_appointments=data.get("existing_appointments", []),
                target_date=data.get("target_date", "2026-10-03"),
            )
            print(json.dumps(res))
        elif action == "cancel":
            res = handle_cancellation(
                appointment_id=data.get("appointment_id", ""),
                appointments=data.get("appointments", []),
                doctors=data.get("doctors", []),
                waiting_list=data.get("waiting_list", []),
            )
            print(json.dumps(res))
        elif action == "doctor-unavailable":
            res = handle_doctor_unavailable(
                doctor_id=data.get("doctor_id", ""),
                doctors=data.get("doctors", []),
                appointments=data.get("appointments", []),
                waiting_list=data.get("waiting_list", []),
                target_date=data.get("target_date", "2026-10-03"),
            )
            print(json.dumps(res))
        else:
            print(json.dumps({"error": f"Unknown action {action}"}))
    except Exception as e:
        print(json.dumps({"error": str(e)}))


def main():
    if len(sys.argv) > 1 and sys.argv[1] == "--dispatch":
        payload = sys.argv[2] if len(sys.argv) > 2 else sys.stdin.read()
        run_cli_dispatch(payload)
        return

    server_address = ("0.0.0.0", PORT)
    httpd = ThreadedHTTPServer(server_address, SchedulerAPIHandler)
    print(f"[*] PulseCare Python DAA Backend running on http://0.0.0.0:{PORT}")
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\n[*] Shutting down Python backend...")
        httpd.server_close()


if __name__ == "__main__":
    main()
