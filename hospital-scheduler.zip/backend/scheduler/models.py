"""
Hospital Appointment Scheduling Engine - Data Models and Constants
"""

from typing import TypedDict, Optional, List, Dict, Any

URGENCY_RANK: Dict[str, int] = {
    "Emergency": 1,
    "Critical": 2,
    "High": 3,
    "Normal": 4,
    "Routine": 5,
    "Low": 5,
}

ALL_STANDARD_SLOTS: List[str] = [
    "09:00",
    "09:30",
    "10:00",
    "10:30",
    "11:00",
    "11:30",
    "12:00",
    "13:30",
    "14:00",
    "14:30",
    "15:00",
    "15:30",
    "16:00",
    "16:30",
]


def time_to_minutes(time_str: Optional[str]) -> int:
    """Parses a time string (e.g. '09:30' or 'Morning (09:00 - 12:00)') to minutes from midnight."""
    if not time_str:
        return 9999
    time_str_lower = time_str.lower()
    if "morning" in time_str_lower:
        return 9 * 60
    if "afternoon" in time_str_lower:
        return 13 * 60 + 30

    parts = time_str.strip().split(":")
    if len(parts) >= 2:
        try:
            hours = int(parts[0])
            minutes = int(parts[1])
            return hours * 60 + minutes
        except ValueError:
            return 9999
    return 9999
