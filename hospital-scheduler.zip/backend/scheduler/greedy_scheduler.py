"""
DAA Concept 3: Greedy Appointment Selection - Python Implementation

Greedy Strategy:
"Select the earliest suitable available appointment slot with a compatible doctor."
Tie-Breaker: Lower current workload (load-balancing), then doctor ID string order.
"""

import time
from typing import Any, Dict, List, Optional, Tuple
from .models import ALL_STANDARD_SLOTS, URGENCY_RANK, time_to_minutes


def find_compatible_doctors(
    department: str, doctors: List[Dict[str, Any]], preferred_doctor_id: Optional[str] = None
) -> List[Dict[str, Any]]:
    """Filters doctors by matching department and active availability."""
    compatible = []
    for doc in doctors:
        if doc.get("department") != department:
            continue
        if doc.get("status") == "Unavailable":
            continue
        compatible.append(doc)
    return compatible


def get_doctor_current_workload(
    doctor_id: str, target_date: str, existing_appointments: List[Dict[str, Any]]
) -> int:
    """Calculates active scheduled appointments for a doctor on a specific date."""
    count = 0
    for apt in existing_appointments:
        if (
            apt.get("doctorId") == doctor_id or apt.get("doctor_id") == doctor_id
        ) and apt.get("date") == target_date and apt.get("status") != "Cancelled":
            count += 1
    return count


def is_slot_occupied(
    doctor_id: str, target_date: str, slot: str, existing_appointments: List[Dict[str, Any]]
) -> bool:
    """Checks if a doctor's slot is already booked on target_date."""
    for apt in existing_appointments:
        match_doc = apt.get("doctorId") == doctor_id or apt.get("doctor_id") == doctor_id
        match_date = apt.get("date") == target_date
        match_slot = apt.get("timeSlot") == slot or apt.get("time_slot") == slot
        not_cancelled = apt.get("status") != "Cancelled"
        if match_doc and match_date and match_slot and not_cancelled:
            return True
    return False


def greedy_assign_appointment(
    patient: Dict[str, Any],
    doctors: List[Dict[str, Any]],
    existing_appointments: List[Dict[str, Any]],
    target_date: str,
    step_number: int = 1,
    queue_extraction_order: int = 1,
) -> Dict[str, Any]:
    """
    Greedy appointment assignment for a single patient extracted from the Priority Queue.
    Evaluates feasible options and picks the earliest compatible doctor+slot tuple.
    """
    dept = patient.get("department", "General Medicine")
    preferred_doctor_id = patient.get("preferredDoctorId") or patient.get("preferred_doctor_id")
    preferred_time_slot = patient.get("preferredTimeSlot") or patient.get("preferred_time_slot")

    candidate_docs = find_compatible_doctors(dept, doctors, preferred_doctor_id)

    candidate_metadata = [
        {
            "id": doc.get("id"),
            "name": doc.get("name"),
            "is_available": doc.get("status") != "Unavailable",
            "current_workload": get_doctor_current_workload(doc.get("id"), target_date, existing_appointments),
            "max_capacity": doc.get("maxDailyCapacity") or doc.get("max_daily_capacity") or 8,
        }
        for doc in candidate_docs
    ]

    evaluated_slots = []

    if not candidate_docs:
        trace_step = {
            "step_number": step_number,
            "patient_id": patient.get("id"),
            "patient_name": patient.get("patientName") or patient.get("patient_name"),
            "urgency": patient.get("urgency", "Normal"),
            "urgency_rank": URGENCY_RANK.get(patient.get("urgency", "Normal"), 5),
            "queue_extraction_order": queue_extraction_order,
            "candidate_doctors": candidate_metadata,
            "evaluated_slots": [],
            "chosen_doctor_id": None,
            "chosen_doctor_name": None,
            "chosen_slot": None,
            "greedy_criterion_met": "No active doctors available in requested department",
            "execution_timestamp": int(time.time() * 1000),
        }
        return {
            "success": False,
            "reason": f"No active physicians available in department {dept}",
            "trace_step": trace_step,
        }

    # Determine slots evaluation order
    slots_to_evaluate = list(ALL_STANDARD_SLOTS)
    if preferred_time_slot:
        pref_lower = preferred_time_slot.lower()
        if "morning" in pref_lower:
            slots_to_evaluate = sorted(
                slots_to_evaluate,
                key=lambda s: (0 if time_to_minutes(s) < 12 * 60 else 1, time_to_minutes(s)),
            )
        elif "afternoon" in pref_lower:
            slots_to_evaluate = sorted(
                slots_to_evaluate,
                key=lambda s: (0 if time_to_minutes(s) >= 12 * 60 else 1, time_to_minutes(s)),
            )
        elif preferred_time_slot in slots_to_evaluate:
            slots_to_evaluate = [preferred_time_slot] + [
                s for s in slots_to_evaluate if s != preferred_time_slot
            ]

    # Sort candidate doctors with tie-breakers:
    # 1. Preferred doctor match
    # 2. Lower current workload (load balancing across doctors)
    # 3. Doctor ID
    def doctor_sort_key(d: Dict[str, Any]):
        doc_id = d.get("id", "")
        is_pref = 0 if preferred_doctor_id and doc_id == preferred_doctor_id else 1
        workload = get_doctor_current_workload(doc_id, target_date, existing_appointments)
        return (is_pref, workload, doc_id)

    sorted_doctors = sorted(candidate_docs, key=doctor_sort_key)

    chosen_doctor = None
    chosen_slot = None
    tie_breaker_note = None

    for slot in slots_to_evaluate:
        for doc in sorted_doctors:
            doc_id = doc.get("id")
            doc_name = doc.get("name")
            roster_slots = doc.get("availableSlots") or doc.get("available_slots") or []

            # Check if doctor roster includes slot
            if slot not in roster_slots:
                evaluated_slots.append({
                    "slot": slot,
                    "doctor_id": doc_id,
                    "doctor_name": doc_name,
                    "is_free": False,
                    "notes": "Slot outside physician daily roster",
                })
                continue

            # Check max capacity
            cap = doc.get("maxDailyCapacity") or doc.get("max_daily_capacity") or 8
            workload = get_doctor_current_workload(doc_id, target_date, existing_appointments)
            if workload >= cap:
                evaluated_slots.append({
                    "slot": slot,
                    "doctor_id": doc_id,
                    "doctor_name": doc_name,
                    "is_free": False,
                    "notes": f"Doctor reached daily maximum capacity ({cap})",
                })
                continue

            # Check if occupied
            if is_slot_occupied(doc_id, target_date, slot, existing_appointments):
                evaluated_slots.append({
                    "slot": slot,
                    "doctor_id": doc_id,
                    "doctor_name": doc_name,
                    "is_free": False,
                    "notes": "Already booked by another patient",
                })
                continue

            # GREEDY CHOICE SATISFIED: Earliest feasible slot with compatible doctor
            evaluated_slots.append({
                "slot": slot,
                "doctor_id": doc_id,
                "doctor_name": doc_name,
                "is_free": True,
                "notes": "Optimal feasible slot selected via greedy rule",
            })
            chosen_doctor = doc
            chosen_slot = slot

            if len(sorted_doctors) > 1:
                tie_breaker_note = (
                    f"Load-balanced to {doc_name} (Current appointments: {workload}/{cap})"
                )
            break

        if chosen_doctor and chosen_slot:
            break

    urgency_name = patient.get("urgency", "Normal")
    patient_name = patient.get("patientName") or patient.get("patient_name")
    is_emergency = urgency_name in ("Emergency", "Critical")

    if not chosen_doctor or not chosen_slot:
        trace_step = {
            "step_number": step_number,
            "patient_id": patient.get("id"),
            "patient_name": patient_name,
            "urgency": urgency_name,
            "urgency_rank": URGENCY_RANK.get(urgency_name, 5),
            "queue_extraction_order": queue_extraction_order,
            "candidate_doctors": candidate_metadata,
            "evaluated_slots": evaluated_slots[:15],
            "chosen_doctor_id": None,
            "chosen_doctor_name": None,
            "chosen_slot": None,
            "greedy_criterion_met": "No open slots within doctor capacity constraints",
            "execution_timestamp": int(time.time() * 1000),
        }
        return {
            "success": False,
            "reason": f"All available slots in {dept} fully booked for {target_date}",
            "trace_step": trace_step,
        }

    # Clinical explanation using natural medical terminology
    explanation = {
        "priorityReason": (
            f"Priority: {urgency_name} Case — prioritized ahead of routine appointments for immediate clinical care."
            if is_emergency
            else f"Priority: {urgency_name} triage urgency level (Queue extraction #{queue_extraction_order})."
        ),
        "doctorReason": f"Doctor: {chosen_doctor.get('name')} ({chosen_doctor.get('specialization', dept)} specialist).",
        "availabilityReason": f"Availability: Physician available at {chosen_slot} ({target_date}).",
        "preferenceMatch": (
            f"Patient preference: Preferred window '{preferred_time_slot}' accommodated."
            if preferred_time_slot
            else "Patient preference: Earliest open consultation window assigned."
        ),
        "decisionSummary": f"{chosen_slot} was the earliest suitable available slot with a compatible specialist.",
    }

    trace_step = {
        "step_number": step_number,
        "patient_id": patient.get("id"),
        "patient_name": patient_name,
        "urgency": urgency_name,
        "urgency_rank": URGENCY_RANK.get(urgency_name, 5),
        "queue_extraction_order": queue_extraction_order,
        "candidate_doctors": candidate_metadata,
        "evaluated_slots": evaluated_slots[:12],
        "chosen_doctor_id": chosen_doctor.get("id"),
        "chosen_doctor_name": chosen_doctor.get("name"),
        "chosen_slot": chosen_slot,
        "greedy_criterion_met": f"Earliest feasible slot ({chosen_slot}) with compatible doctor ({chosen_doctor.get('name')})",
        "tie_breaker_used": tie_breaker_note,
        "execution_timestamp": int(time.time() * 1000),
    }

    new_appointment = {
        "id": f"apt-{int(time.time() * 1000)}-{chosen_doctor.get('id')[-4:]}",
        "patientId": patient.get("id"),
        "patientName": patient_name,
        "patientAge": patient.get("age", 35),
        "patientContact": patient.get("contact", ""),
        "patientUrgency": urgency_name,
        "doctorId": chosen_doctor.get("id"),
        "doctorName": chosen_doctor.get("name"),
        "department": dept,
        "date": target_date,
        "timeSlot": chosen_slot,
        "status": "Confirmed",
        "bookedAt": int(time.time() * 1000),
        "selectionExplanation": explanation,
        "algorithmTrace": trace_step,
    }

    return {
        "success": True,
        "appointment": new_appointment,
        "trace_step": trace_step,
    }
