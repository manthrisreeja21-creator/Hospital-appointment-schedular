"""
DAA Concept 2: Priority Queue - Python Implementation

Uses Python's binary min-heap (heapq) module.
In hospital triage, Emergency holds rank 1 (highest clinical priority),
down to Routine (rank 5).
Lower numerical priority value = Higher triage position.
"""

import heapq
from typing import Any, Dict, List, Optional, Tuple
from .models import URGENCY_RANK, time_to_minutes


class PriorityQueue:
    """
    Min-Heap Priority Queue for patient triage and dynamic appointment allocation.
    """

    def __init__(self):
        # The heap stores tuples of (priority_rank, tie_breaker_minutes, timestamp, insertion_counter, patient_dict)
        self._heap: List[Tuple[int, int, int, int, Dict[str, Any]]] = []
        self._counter: int = 0
        self.history_inserted: List[Dict[str, Any]] = []
        self.history_extracted: List[Dict[str, Any]] = []

    def insert(self, patient: Dict[str, Any]) -> None:
        """
        Inserts a patient into the priority queue.
        Time Complexity: O(log N)
        """
        urgency_name = patient.get("urgency", "Normal")
        priority_rank = URGENCY_RANK.get(urgency_name, 5)

        preferred_slot = patient.get("preferredTimeSlot") or patient.get("preferred_time_slot")
        tie_breaker_minutes = time_to_minutes(preferred_slot)

        timestamp = int(patient.get("requestTimestamp") or patient.get("request_timestamp") or 0)
        self._counter += 1

        entry = (priority_rank, tie_breaker_minutes, timestamp, self._counter, patient)
        heapq.heappush(self._heap, entry)

        self.history_inserted.append({
            "order": self._counter,
            "patient_id": patient.get("id"),
            "patient_name": patient.get("patientName") or patient.get("patient_name"),
            "urgency": urgency_name,
            "priority_rank": priority_rank,
            "queue_size_after": len(self._heap),
        })

    def peek(self) -> Optional[Dict[str, Any]]:
        """
        Returns the highest-priority patient without removing it from the queue.
        Time Complexity: O(1)
        """
        if not self._heap:
            return None
        return self._heap[0][4]

    def peek_priority(self) -> Optional[int]:
        """Returns the numerical priority rank of the root item."""
        if not self._heap:
            return None
        return self._heap[0][0]

    def extract_highest_priority(self) -> Optional[Dict[str, Any]]:
        """
        Extracts and returns the patient with the highest clinical urgency (lowest numerical rank).
        Time Complexity: O(log N)
        """
        if not self._heap:
            return None
        priority_rank, tie_breaker, timestamp, counter, patient = heapq.heappop(self._heap)

        step_record = {
            "extraction_order": len(self.history_extracted) + 1,
            "patient_id": patient.get("id"),
            "patient_name": patient.get("patientName") or patient.get("patient_name"),
            "urgency": patient.get("urgency", "Normal"),
            "priority_rank": priority_rank,
            "queue_size_remaining": len(self._heap),
        }
        self.history_extracted.append(step_record)
        return patient

    def is_empty(self) -> bool:
        """Returns True if the priority queue contains no elements."""
        return len(self._heap) == 0

    def size(self) -> int:
        """Returns the total number of patients currently in the priority queue."""
        return len(self._heap)

    def get_heap_array(self) -> List[Dict[str, Any]]:
        """
        Returns the underlying binary heap array for UI heap visualization and inspection.
        """
        result = []
        for idx, (rank, tie, ts, c, patient) in enumerate(self._heap):
            parent_idx = None if idx == 0 else (idx - 1) // 2
            left_child_idx = 2 * idx + 1 if (2 * idx + 1) < len(self._heap) else None
            right_child_idx = 2 * idx + 2 if (2 * idx + 2) < len(self._heap) else None

            result.append({
                "heap_index": idx,
                "parent_index": parent_idx,
                "left_child_index": left_child_idx,
                "right_child_index": right_child_idx,
                "priority_rank": rank,
                "tie_breaker_minutes": tie,
                "patient_id": patient.get("id"),
                "patient_name": patient.get("patientName") or patient.get("patient_name"),
                "urgency": patient.get("urgency", "Normal"),
                "department": patient.get("department"),
            })
        return result
