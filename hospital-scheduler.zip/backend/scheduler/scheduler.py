"""
Complete DAA Hospital Scheduling Engine - Python Implementation

Coordinates:
1. Sorting (sort_patients)
2. Priority Queue (heapq Min-Heap)
3. Greedy Strategy (greedy_assign_appointment)
4. Dynamic Rescheduling & Cancellations
"""

import time
from typing import Any, Dict, List, Optional
from .models import URGENCY_RANK
from .sorting import sort_patients, get_sorting_trace
from .priority_queue import PriorityQueue
from .greedy_scheduler import greedy_assign_appointment


def schedule_appointments(
    patients: List[Dict[str, Any]],
    doctors: List[Dict[str, Any]],
    existing_appointments: Optional[List[Dict[str, Any]]] = None,
    target_date: str = "2026-10-03",
) -> Dict[str, Any]:
    """
    Main DAA scheduling pipeline execution in Python.
    """
    if existing_appointments is None:
        existing_appointments = []

    current_appointments = list(existing_appointments)

    # 1. SORTING: Organize patient requests deterministically by urgency
    sorting_trace = get_sorting_trace(patients)
    sorted_patients = sort_patients(patients)

    # 2. PRIORITY QUEUE: Insert sorted patients into heapq Min-Heap
    pq = PriorityQueue()
    for patient in sorted_patients:
        pq.insert(patient)

    new_appointments = []
    waiting_list = []
    greedy_steps = []

    step_number = 1
    extraction_order = 1

    # 3. PRIORITY-BASED SELECTION & GREEDY SLOT ASSIGNMENT
    while not pq.is_empty():
        patient = pq.extract_highest_priority()
        if not patient:
            break

        assignment = greedy_assign_appointment(
            patient=patient,
            doctors=doctors,
            existing_appointments=current_appointments,
            target_date=target_date,
            step_number=step_number,
            queue_extraction_order=extraction_order,
        )

        step_number += 1
        extraction_order += 1
        greedy_steps.append(assignment.get("trace_step"))

        if assignment.get("success") and assignment.get("appointment"):
            apt = assignment["appointment"]
            new_appointments.append(apt)
            current_appointments.append(apt)
        else:
            waiting_patient = dict(patient)
            waiting_patient["status"] = "Waiting"
            waiting_list.append(waiting_patient)

    doctors_used = len({a.get("doctorId") for a in new_appointments if a.get("doctorId")})
    emergencies_handled = sum(
        1 for a in new_appointments if a.get("patientUrgency") in ("Emergency", "Critical")
    )

    execution_data = {
        "sorting": sorting_trace,
        "priority_queue_insertions": pq.history_inserted,
        "priority_queue_extractions": pq.history_extracted,
        "priority_queue_steps": pq.history_extracted,
        "greedy_steps": greedy_steps,
        "doctors_utilized": doctors_used,
        "emergencies_handled": emergencies_handled,
        "scheduled_count": len(new_appointments),
        "waiting_count": len(waiting_list),
        "target_date": target_date,
        "timestamp": int(time.time() * 1000),
    }

    return {
        "appointments": new_appointments,
        "updated_appointments": current_appointments,
        "waiting_list": waiting_list,
        "execution": execution_data,
    }


def handle_cancellation(
    appointment_id: str,
    appointments: List[Dict[str, Any]],
    doctors: List[Dict[str, Any]],
    waiting_list: List[Dict[str, Any]],
) -> Dict[str, Any]:
    """
    Frees an appointment slot and immediately reallocates it to the highest-priority
    waiting patient using the Python Priority Queue.
    """
    target_apt = None
    updated_appointments = []
    for apt in appointments:
        if apt.get("id") == appointment_id:
            target_apt = apt
            cancelled = dict(apt)
            cancelled["status"] = "Cancelled"
            updated_appointments.append(cancelled)
        else:
            updated_appointments.append(apt)

    if not target_apt:
        return {
            "updated_appointments": appointments,
            "updated_waiting_list": waiting_list,
            "promoted_appointment": None,
        }

    dept = target_apt.get("department")
    eligible_waiting = [w for w in waiting_list if w.get("department") == dept]
    other_waiting = [w for w in waiting_list if w.get("department") != dept]

    if not eligible_waiting:
        return {
            "updated_appointments": updated_appointments,
            "updated_waiting_list": waiting_list,
            "promoted_appointment": None,
        }

    # Use Priority Queue to extract the highest-priority patient waiting for this department
    pq = PriorityQueue()
    for w in eligible_waiting:
        pq.insert(w)

    promoted_patient = pq.extract_highest_priority()
    if not promoted_patient:
        return {
            "updated_appointments": updated_appointments,
            "updated_waiting_list": waiting_list,
            "promoted_appointment": None,
        }

    doc_id = target_apt.get("doctorId")
    doc_name = target_apt.get("doctorName", "Specialist")

    explanation = {
        "priorityReason": f"Promoted from waiting queue due to urgent clinical priority ({promoted_patient.get('urgency', 'Normal')}).",
        "doctorReason": f"Reallocated to {doc_name} following slot cancellation.",
        "availabilityReason": f"Slot {target_apt.get('timeSlot')} on {target_apt.get('date')} became immediately vacant.",
        "preferenceMatch": "Expedited priority waiting list assignment.",
        "decisionSummary": f"Allocated freed slot ({target_apt.get('timeSlot')}) to highest-priority waiting patient via Python Priority Queue.",
    }

    promoted_apt = {
        "id": f"apt-promo-{int(time.time() * 1000)}",
        "patientId": promoted_patient.get("id"),
        "patientName": promoted_patient.get("patientName") or promoted_patient.get("patient_name"),
        "patientAge": promoted_patient.get("age", 35),
        "patientContact": promoted_patient.get("contact", ""),
        "patientUrgency": promoted_patient.get("urgency", "Normal"),
        "doctorId": doc_id,
        "doctorName": doc_name,
        "department": dept,
        "date": target_apt.get("date"),
        "timeSlot": target_apt.get("timeSlot"),
        "status": "Confirmed",
        "bookedAt": int(time.time() * 1000),
        "selectionExplanation": explanation,
    }

    updated_appointments.append(promoted_apt)

    remaining_dept_waiting = []
    while not pq.is_empty():
        p = pq.extract_highest_priority()
        if p:
            remaining_dept_waiting.append(p)

    return {
        "updated_appointments": updated_appointments,
        "updated_waiting_list": other_waiting + remaining_dept_waiting,
        "promoted_appointment": promoted_apt,
    }


def handle_no_show(
    appointment_id: str,
    appointments: List[Dict[str, Any]],
    doctors: List[Dict[str, Any]],
    waiting_list: List[Dict[str, Any]],
) -> Dict[str, Any]:
    """Marks an appointment as No-Show."""
    updated = []
    for apt in appointments:
        if apt.get("id") == appointment_id:
            no_show = dict(apt)
            no_show["status"] = "No Show"
            updated.append(no_show)
        else:
            updated.append(apt)
    return {
        "updated_appointments": updated,
        "updated_waiting_list": waiting_list,
    }


def handle_doctor_unavailable(
    doctor_id: str,
    doctors: List[Dict[str, Any]],
    appointments: List[Dict[str, Any]],
    waiting_list: List[Dict[str, Any]],
    target_date: str = "2026-10-03",
) -> Dict[str, Any]:
    """
    Dynamic Rescheduling when a doctor becomes unavailable.
    Identifies displaced appointments, finds compatible doctors, and re-executes
    the Priority Queue and Greedy Scheduler for those patients.
    """
    unavailable_doc = None
    updated_doctors = []
    for d in doctors:
        if d.get("id") == doctor_id:
            unavailable_doc = d
            d_copy = dict(d)
            d_copy["status"] = "Unavailable"
            updated_doctors.append(d_copy)
        else:
            updated_doctors.append(d)

    doctor_name = unavailable_doc.get("name", "Physician") if unavailable_doc else "Physician"
    department = unavailable_doc.get("department", "General Medicine") if unavailable_doc else "General Medicine"

    affected_appointments = [
        apt for apt in appointments
        if (apt.get("doctorId") == doctor_id or apt.get("doctor_id") == doctor_id)
        and apt.get("date") == target_date
        and apt.get("status") not in ("Cancelled", "Completed")
    ]

    unaffected_appointments = [
        apt for apt in appointments
        if not (
            (apt.get("doctorId") == doctor_id or apt.get("doctor_id") == doctor_id)
            and apt.get("date") == target_date
            and apt.get("status") not in ("Cancelled", "Completed")
        )
    ]

    # Convert affected appointments into patient requests for priority rescheduling
    requests_to_reschedule = [
        {
            "id": apt.get("patientId"),
            "patientName": apt.get("patientName"),
            "age": apt.get("patientAge", 35),
            "contact": apt.get("patientContact", ""),
            "department": apt.get("department"),
            "urgency": apt.get("patientUrgency", "Normal"),
            "preferredDate": apt.get("date", target_date),
            "preferredTimeSlot": apt.get("timeSlot"),
            "symptoms": f"Rescheduling due to doctor absence ({doctor_name})",
            "requestTimestamp": apt.get("bookedAt", int(time.time() * 1000)),
            "status": "Pending",
        }
        for apt in affected_appointments
    ]

    dept_waiting = [w for w in waiting_list if w.get("department") == department]
    other_waiting = [w for w in waiting_list if w.get("department") != department]

    combined_requests = requests_to_reschedule + dept_waiting

    # Re-run priority scheduling in Python
    scheduling_result = schedule_appointments(
        patients=combined_requests,
        doctors=updated_doctors,
        existing_appointments=unaffected_appointments,
        target_date=target_date,
    )

    newly_created = scheduling_result["appointments"]
    # Mark displaced appointments as 'Rescheduled'
    final_new_appointments = []
    for apt in newly_created:
        was_displaced = any(aff.get("patientId") == apt.get("patientId") for aff in affected_appointments)
        if was_displaced:
            apt_copy = dict(apt)
            apt_copy["status"] = "Rescheduled"
            apt_copy["rescheduledFromDoctorId"] = doctor_id
            apt_copy["rescheduleReason"] = f"Automatically reassigned from {doctor_name} (Doctor Unavailable)"
            final_new_appointments.append(apt_copy)
        else:
            final_new_appointments.append(apt)

    incident_details = []
    for aff in affected_appointments:
        reassigned = next(
            (n for n in final_new_appointments if n.get("patientId") == aff.get("patientId")),
            None,
        )
        if reassigned:
            incident_details.append({
                "patientName": aff.get("patientName"),
                "urgency": aff.get("patientUrgency"),
                "originalSlot": aff.get("timeSlot"),
                "newDoctorName": reassigned.get("doctorName"),
                "newSlot": reassigned.get("timeSlot"),
                "status": "Rescheduled",
            })
        else:
            incident_details.append({
                "patientName": aff.get("patientName"),
                "urgency": aff.get("patientUrgency"),
                "originalSlot": aff.get("timeSlot"),
                "status": "Moved to Waiting",
            })

    incident = {
        "id": f"INC-{int(time.time() * 1000)}",
        "timestamp": int(time.time() * 1000),
        "unavailableDoctorId": doctor_id,
        "unavailableDoctorName": doctor_name,
        "department": department,
        "affectedAppointmentsCount": len(affected_appointments),
        "successfullyRescheduledCount": sum(1 for d in incident_details if d["status"] == "Rescheduled"),
        "movedToWaitingCount": sum(1 for d in incident_details if d["status"] == "Moved to Waiting"),
        "details": incident_details,
    }

    return {
        "updated_doctors": updated_doctors,
        "updated_appointments": unaffected_appointments + final_new_appointments,
        "new_waiting_requests": other_waiting + scheduling_result["waiting_list"],
        "incident": incident,
        "execution": scheduling_result["execution"],
    }
