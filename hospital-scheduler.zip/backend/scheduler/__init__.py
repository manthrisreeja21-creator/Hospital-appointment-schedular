"""
Hospital Appointment Scheduling Engine - DAA Package
"""

from .models import URGENCY_RANK, ALL_STANDARD_SLOTS, time_to_minutes
from .sorting import sort_patients, get_sorting_trace
from .priority_queue import PriorityQueue
from .greedy_scheduler import greedy_assign_appointment, find_compatible_doctors
from .scheduler import (
    schedule_appointments,
    handle_cancellation,
    handle_no_show,
    handle_doctor_unavailable,
)

__all__ = [
    "URGENCY_RANK",
    "ALL_STANDARD_SLOTS",
    "time_to_minutes",
    "sort_patients",
    "get_sorting_trace",
    "PriorityQueue",
    "greedy_assign_appointment",
    "find_compatible_doctors",
    "schedule_appointments",
    "handle_cancellation",
    "handle_no_show",
    "handle_doctor_unavailable",
]
