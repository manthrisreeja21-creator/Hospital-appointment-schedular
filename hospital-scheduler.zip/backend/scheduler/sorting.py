"""
DAA Concept 1: Sorting - Python Implementation

Organizes patient requests deterministically according to healthcare triage priority:
1. Urgency: Emergency (1) -> Critical (2) -> High (3) -> Normal (4) -> Routine (5)
2. Requested / preferred appointment time window
3. Request arrival timestamp (FIFO stability within tier)
4. Patient ID
"""

from typing import List, Dict, Any, Tuple
from .models import URGENCY_RANK, time_to_minutes


def patient_sort_key(patient: Dict[str, Any]) -> Tuple[int, int, int, str]:
    """Generates a deterministic 4-tier comparison tuple for patient triage."""
    urgency_name = patient.get("urgency", "Normal")
    rank = URGENCY_RANK.get(urgency_name, 5)

    preferred_slot = patient.get("preferredTimeSlot") or patient.get("preferred_time_slot")
    time_min = time_to_minutes(preferred_slot)

    timestamp = int(patient.get("requestTimestamp") or patient.get("request_timestamp") or 0)
    patient_id = str(patient.get("id", ""))

    return (rank, time_min, timestamp, patient_id)


def sort_patients(patients: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """
    Sorts patient appointment requests using the deterministic triage key.
    Time Complexity: O(N log N) using Python's Timsort.
    """
    return sorted(patients, key=patient_sort_key)


def get_sorting_trace(patients: List[Dict[str, Any]]) -> Dict[str, Any]:
    """
    Returns the sorted patients list along with execution metadata for DAA evaluation.
    """
    sorted_list = sort_patients(patients)
    tier_counts = {
        "Emergency": 0,
        "Critical": 0,
        "High": 0,
        "Normal": 0,
        "Routine": 0,
    }
    for p in sorted_list:
        urg = p.get("urgency", "Normal")
        if urg in tier_counts:
            tier_counts[urg] += 1
        elif urg == "Low":
            tier_counts["Routine"] += 1

    return {
        "total_sorted": len(sorted_list),
        "tier_counts": tier_counts,
        "sorted_patient_ids": [p.get("id") for p in sorted_list],
        "sorted_patient_summary": [
            {
                "id": p.get("id"),
                "name": p.get("patientName") or p.get("patient_name"),
                "urgency": p.get("urgency"),
                "rank": URGENCY_RANK.get(p.get("urgency", "Normal"), 5),
                "department": p.get("department"),
            }
            for p in sorted_list
        ],
        "primary_criterion": "Urgency (Emergency -> Critical -> High -> Normal -> Routine)",
        "secondary_criterion": "Preferred Consultation Time Slot (Minutes from midnight)",
        "tertiary_criterion": "Request Arrival Timestamp (FIFO within urgency tier)",
    }
