import express from 'express';
import { spawn, ChildProcess } from 'child_process';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;
const PYTHON_PORT = process.env.PYTHON_PORT || 8000;

app.use(express.json({ limit: '10mb' }));

// Start Python DAA Backend Process
let pythonProcess: ChildProcess | null = null;

function startPythonBackend() {
  const pythonScript = path.resolve(__dirname, 'backend', 'main.py');
  console.log(`[Server] Launching Python DAA backend: python3 ${pythonScript}`);

  pythonProcess = spawn('python3', [pythonScript], {
    env: { ...process.env, PYTHON_PORT: String(PYTHON_PORT) },
    stdio: 'inherit',
  });

  pythonProcess.on('error', (err) => {
    console.error('[Server] Failed to start Python backend process:', err);
  });

  pythonProcess.on('exit', (code, signal) => {
    console.log(`[Server] Python backend exited with code ${code}, signal ${signal}`);
  });
}

startPythonBackend();

// Function to forward API calls to Python HTTP server with fallback to CLI dispatch
async function forwardToPython(endpoint: string, method: string, body?: any): Promise<any> {
  const pythonUrl = `http://127.0.0.1:${PYTHON_PORT}${endpoint}`;

  try {
    const response = await fetch(pythonUrl, {
      method,
      headers: {
        'Content-Type': 'application/json',
      },
      body: body ? JSON.stringify(body) : undefined,
    });

    if (response.ok) {
      return await response.json();
    }
    const errText = await response.text();
    throw new Error(`Python API returned ${response.status}: ${errText}`);
  } catch (httpErr) {
    // Resilient fallback: Run Python directly via CLI dispatch if HTTP connection fails
    console.warn(`[Server] Python HTTP connection failed, executing via Python CLI dispatch fallback...`, httpErr);

    let action = 'schedule';
    if (endpoint.includes('cancel')) action = 'cancel';
    else if (endpoint.includes('doctor-unavailable')) action = 'doctor-unavailable';
    else if (endpoint.includes('appointment')) action = 'appointment';

    return new Promise((resolve, reject) => {
      const payload = JSON.stringify({ action, ...(body || {}) });
      const script = path.resolve(__dirname, 'backend', 'main.py');
      const py = spawn('python3', [script, '--dispatch', payload]);

      let stdout = '';
      let stderr = '';

      py.stdout.on('data', (d) => {
        stdout += d.toString();
      });
      py.stderr.on('data', (d) => {
        stderr += d.toString();
      });

      py.on('close', (code) => {
        if (code === 0) {
          try {
            resolve(JSON.parse(stdout));
          } catch (e) {
            reject(new Error(`Invalid JSON from Python dispatch: ${stdout}`));
          }
        } else {
          reject(new Error(`Python process exited with ${code}: ${stderr}`));
        }
      });
    });
  }
}

// API Routes Proxied to Python DAA Backend
app.all('/api/*', async (req, res) => {
  try {
    const result = await forwardToPython(req.originalUrl, req.method, req.body);
    res.json(result);
  } catch (err: any) {
    console.error(`[Server] Error forwarding to Python:`, err);
    res.status(500).json({ error: err.message || 'Internal Server Error', success: false });
  }
});

// Setup Vite or Static File Serving
async function setupFrontend() {
  if (process.env.NODE_ENV === 'production') {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  } else {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  app.listen(PORT, () => {
    console.log(`[Server] Hospital Scheduler running at http://localhost:${PORT}`);
  });
}

setupFrontend();

// Cleanup on exit
process.on('SIGINT', () => {
  if (pythonProcess) pythonProcess.kill();
  process.exit();
});

process.on('SIGTERM', () => {
  if (pythonProcess) pythonProcess.kill();
  process.exit();
});
